package com.latchi.iptv.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R

class CategoryGridAdapter(
    private var categories: List<CategoryItem>,
    private val onSelect: (CategoryItem) -> Unit
) : RecyclerView.Adapter<CategoryGridAdapter.CatViewHolder>() {

    data class CategoryItem(val name: String, val count: Int)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CatViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_category_grid, parent, false)
        return CatViewHolder(view)
    }

    override fun onBindViewHolder(holder: CatViewHolder, position: Int) = holder.bind(categories[position])
    override fun getItemCount(): Int = categories.size

    fun update(newList: List<CategoryItem>) {
        categories = newList
        notifyDataSetChanged()
    }

    inner class CatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val iconText: TextView = itemView.findViewById(R.id.catGridIcon)
        private val nameText: TextView = itemView.findViewById(R.id.catGridName)
        private val countText: TextView = itemView.findViewById(R.id.catGridCount)

        fun bind(item: CategoryItem) {
            nameText.text = if (item.name == "All") "كل القنوات" else if (item.name == "Favorites") "⭐ المفضلة" else item.name
            countText.text = "${item.count} قناة"

            iconText.text = when {
                item.name == "All" -> "🗂"
                item.name == "Favorites" -> "⭐"
                item.name.lowercase().contains("bein") -> "🟣"
                item.name.lowercase().contains("ssc") -> "🟢"
                item.name.lowercase().contains("alkass") -> "🟠"
                item.name.lowercase().contains("osn") -> "🔵"
                item.name.lowercase().contains("movie") || item.name.lowercase().contains("film") -> "🎬"
                item.name.lowercase().contains("series") || item.name.lowercase().contains("مسلسل") -> "📼"
                else -> "📺"
            }

            itemView.setOnClickListener {
                // 🌪 Elastic Spring / Bounce Animation Effect 🌪
                itemView.animate().cancel()
                itemView.scaleX = 0.8f
                itemView.scaleY = 0.8f
                itemView.animate()
                    .scaleX(1.15f).scaleY(1.15f)
                    .setDuration(160)
                    .setInterpolator(OvershootInterpolator(4f))
                    .withEndAction {
                        itemView.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        onSelect(item)
                    }
                    .start()
            }
        }
    }
}
