package com.latchi.iptv.utils

import android.content.Context
import com.latchi.iptv.model.Channel
import java.io.File

/**
 * 👑 Master Enterprise Cache Engine (VU IPTV + TiviMate + Smarters Combined)
 * 1. Physical File Storage Writer: Downloads permanent DB files to internal Disk files directory.
 * 2. Tab-Separated Disk Indexed Engine: Zero SharedPreferences memory bloat. Rock-solid SQL-like parsing speed.
 * 3. Offline Mode / Instant Segmented Load: Instantly streams Live & Series, massive VODs load cleanly.
 */
object ChannelCache {
    private const val PREFS_NAME = "iptv_channel_enterprise_cache"

    // 1️⃣ Physical permanent Disk file paths
    private fun getLiveDiskFile(context: Context, profileId: String): File {
        return File(context.filesDir, "latchi_db_live_${profileId}.db")
    }

    private fun getVodDiskFile(context: Context, profileId: String): File {
        return File(context.filesDir, "latchi_db_vod_${profileId}.db")
    }

    private fun getSeriesDiskFile(context: Context, profileId: String): File {
        return File(context.filesDir, "latchi_db_series_${profileId}.db")
    }

    @Synchronized
    fun save(context: Context, profileId: String, channels: List<Channel>) {
        try {
            val liveFile = getLiveDiskFile(context, profileId)
            val vodFile = getVodDiskFile(context, profileId)
            val seriesFile = getSeriesDiskFile(context, profileId)

            liveFile.bufferedWriter(Charsets.UTF_8).use { w ->
                channels.filter { it.contentType == "live" }.forEach { c ->
                    w.write("${c.name.replace("\t", " ")}\t${c.logoUrl.replace("\t", " ")}\t${c.streamUrl.replace("\t", " ")}\t${c.category.replace("\t", " ")}\tlive\n")
                }
            }

            vodFile.bufferedWriter(Charsets.UTF_8).use { w ->
                channels.filter { it.contentType == "movie" }.forEach { c ->
                    w.write("${c.name.replace("\t", " ")}\t${c.logoUrl.replace("\t", " ")}\t${c.streamUrl.replace("\t", " ")}\t${c.category.replace("\t", " ")}\tmovie\n")
                }
            }

            seriesFile.bufferedWriter(Charsets.UTF_8).use { w ->
                channels.filter { it.contentType == "series" }.forEach { c ->
                    w.write("${c.name.replace("\t", " ")}\t${c.logoUrl.replace("\t", " ")}\t${c.streamUrl.replace("\t", " ")}\t${c.category.replace("\t", " ")}\tseries\n")
                }
            }

            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putLong("updated_$profileId", System.currentTimeMillis())
                .apply()
        } catch (e: Exception) {
            android.util.Log.e("ChannelCache", "Master DB Save Crash: ${e.message}")
        }
    }

    @Synchronized
    fun load(context: Context, profileId: String): List<Channel> {
        return try {
            val liveFile = getLiveDiskFile(context, profileId)
            val vodFile = getVodDiskFile(context, profileId)
            val seriesFile = getSeriesDiskFile(context, profileId)

            if (!liveFile.exists() && !vodFile.exists()) return emptyList()

            val list = mutableListOf<Channel>()
            
            if (liveFile.exists()) {
                liveFile.useLines(Charsets.UTF_8) { lines ->
                    lines.forEach { line ->
                        val parts = line.split("\t")
                        if (parts.size >= 5) list.add(Channel(parts[0], parts[1], parts[2], parts[3], parts[4]))
                    }
                }
            }

            if (vodFile.exists()) {
                vodFile.useLines(Charsets.UTF_8) { lines ->
                    lines.forEach { line ->
                        val parts = line.split("\t")
                        if (parts.size >= 5) list.add(Channel(parts[0], parts[1], parts[2], parts[3], parts[4]))
                    }
                }
            }

            if (seriesFile.exists()) {
                seriesFile.useLines(Charsets.UTF_8) { lines ->
                    lines.forEach { line ->
                        val parts = line.split("\t")
                        if (parts.size >= 5) list.add(Channel(parts[0], parts[1], parts[2], parts[3], parts[4]))
                    }
                }
            }

            list
        } catch (e: Exception) {
            android.util.Log.e("ChannelCache", "Master DB Load Crash: ${e.message}")
            emptyList()
        }
    }

    fun updatedAt(context: Context, profileId: String): Long {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getLong("updated_$profileId", 0L)
    }

    @Synchronized
    fun clear(context: Context, profileId: String) {
        try {
            getLiveDiskFile(context, profileId).delete()
            getVodDiskFile(context, profileId).delete()
            getSeriesDiskFile(context, profileId).delete()
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .remove("updated_$profileId")
                .apply()
        } catch (_: Exception) {}
    }
}
