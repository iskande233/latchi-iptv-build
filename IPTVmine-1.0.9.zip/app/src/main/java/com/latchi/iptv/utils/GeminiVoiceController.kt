package com.latchi.iptv.utils

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiVoiceController {

    const val API_KEY = "" // API Key is read from source or custom helper
    private const val GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key="

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    data class VoiceAction(
        val actionType: String,
        val target: String,
        val screen: String?,
        val extra: String = "",
        val confidence: Float = 1.0f
    ) {
        fun isConfident(): Boolean = confidence >= 0.5f
    }

    fun processVoiceCommand(
        context: Context,
        voiceText: String,
        onResult: (VoiceAction) -> Unit,
        onError: (String) -> Unit
    ) {
        val apiKey = getActualApiKey(context)
        if (apiKey.isBlank()) {
            val parsed = VoiceCommandParser.parse(voiceText)
            onResult(convertToGeminiAction(parsed))
            return
        }

        Thread {
            try {
                val prompt = buildDarjaPrompt(voiceText)
                val requestBody = buildGeminiRequestBody(prompt)
                val request = Request.Builder()
                    .url(GEMINI_URL + apiKey)
                    .header("Content-Type", "application/json")
                    .post(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        val err = response.body?.string() ?: "HTTP ${response.code}"
                        throw Exception("Gemini Error: $err")
                    }
                    val body = response.body?.string() ?: throw Exception("Empty body")
                    val action = parseGeminiResponse(body, voiceText)
                    Handler(Looper.getMainLooper()).post { onResult(action) }
                }
            } catch (e: Exception) {
                Log.e("GeminiVoice", "Crash: ${e.message}")
                val parsed = VoiceCommandParser.parse(voiceText)
                Handler(Looper.getMainLooper()).post { onResult(convertToGeminiAction(parsed)) }
            }
        }.start()
    }

    private fun getActualApiKey(context: Context): String {
        return try {
            GeminiHelper.API_KEY.ifBlank { API_KEY }
        } catch (_: Exception) { API_KEY }
    }

    private fun buildDarjaPrompt(voiceText: String): String {
        return """
أنت مساعد صوتي ذكي لتطبيق IPTV جزائري. المستخدم يتكلم بالدارجة الجزائرية أو الفصحى أو الفرنسية.
تحلل الجملة وتُرجع JSON فقط:

[ ${voiceText} ]

أنواع الأوامر:
1. play — تشغيل قناة أو فيلم أو مسلسل ("شغل beIN", "دير العارضة")
2. navigate — الانتقال لصفحة ("روح للإعدادات", "allez à matchs")
3. search — البحث ("حوسلي على فيلم action")
4. control — التحكم ("وقف", "kemel", "صوت اكثر")
5. info — معلومات
6. unknown — ما فهمتش

رجع JSON بالضبط بهذا الشكل:
```json
{
  "actionType": "play|navigate|search|control|info|unknown",
  "target": "اسم القناة أو الفيلم",
  "screen": "live|movies|series|matches|settings|users|prayer|pricing|about|null",
  "extra": "",
  "confidence": 0.95
}
```
""".trimIndent()
    }

    private fun buildGeminiRequestBody(promptText: String): okhttp3.RequestBody {
        val parts = JSONArray().put(JSONObject().put("text", promptText))
        val contents = JSONArray().put(JSONObject().put("parts", parts))
        val json = JSONObject().put("contents", contents)
        return json.toString().toRequestBody("application/json".toMediaTypeOrNull())
    }

    private fun parseGeminiResponse(response: String, originalText: String): VoiceAction {
        return try {
            val json = JSONObject(response)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) return fallbackAction(originalText)

            val text = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")?.getJSONObject(0)?.optString("text", "") ?: ""
            val cleanJson = text.replace("```json", "").replace("```", "").trim()
            val actionJson = JSONObject(cleanJson)

            VoiceAction(
                actionType = actionJson.optString("actionType", "unknown"),
                target = actionJson.optString("target", ""),
                screen = actionJson.optString("screen", null),
                extra = actionJson.optString("extra", ""),
                confidence = actionJson.optDouble("confidence", 1.0).toFloat()
            )
        } catch (e: Exception) {
            fallbackAction(originalText)
        }
    }

    private fun convertToGeminiAction(parsed: VoiceCommand): VoiceAction {
        return when (parsed) {
            is VoiceCommand.Play -> VoiceAction("play", parsed.channelName, null, "", 0.95f)
            is VoiceCommand.Navigate -> VoiceAction("navigate", "", when (parsed.screen) {
                VoiceCommand.Screen.LIVE -> "live"
                VoiceCommand.Screen.MOVIES -> "movies"
                VoiceCommand.Screen.SERIES -> "series"
                VoiceCommand.Screen.MATCHES -> "matches"
                VoiceCommand.Screen.SETTINGS -> "settings"
                VoiceCommand.Screen.USERS -> "users"
                VoiceCommand.Screen.PRICING -> "pricing"
                VoiceCommand.Screen.PRAYER -> "prayer"
                VoiceCommand.Screen.ABOUT -> "about"
            }, "", 0.95f)
            is VoiceCommand.Search -> VoiceAction("search", parsed.query, null, "", 0.9f)
            VoiceCommand.Unknown -> fallbackAction("")
        }
    }

    private fun fallbackAction(text: String): VoiceAction = VoiceAction("unknown", text, null, "", 0.1f)
}
