package com.latchi.iptv.utils

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * 🧠 Gemini Voice Controller - العقل الذكي للأوامر الصوتية
 * يفهم الدارجة الجزائرية ويتحكم في كل شيء بالتطبيق
 * 
 * استراتيجية: Hybrid (هجين)
 * 1. VoiceCommandParser (مجاني/فوري) للأوامر البسيطة
 * 2. Gemini (ذكي) للأوامر المعقدة والدارجة
 */
object GeminiVoiceController {

    // ⚠️ يُملأ من البناء (BuildConfig) أو الإعدادات
    var API_KEY: String = ""
        private set

    private const val MODEL = "gemini-2.0-flash"
    private const val TIMEOUT_MS = 8000

    /**
     * 🗃️ كاش ذكي: نفس الجملة = نفس النتيجة (24 ساعة)
     * يوفر 60-80% من استدعاءات API
     */
    private val responseCache = ConcurrentHashMap<String, CachedResponse>()
    private const val CACHE_TTL_MS = 24 * 60 * 60 * 1000 // 24 ساعة

    data class CachedResponse(
        val action: VoiceAction,
        val timestamp: Long = System.currentTimeMillis()
    ) {
        fun isValid(): Boolean = (System.currentTimeMillis() - timestamp) < CACHE_TTL_MS
    }

    /**
     * 🎯 نتيجة فهم Gemini — منظمة وواضحة
     */
    data class VoiceAction(
        val actionType: String,   // "play", "navigate", "search", "control", "unknown"
        val target: String,       // اسم القناة أو الفيلم أو المسلسل
        val screen: String?,      // إذا كان تنقل
        val extra: String,        // معلومات إضافية
        val confidence: Float     // 0.0 - 1.0
    ) {
        fun isConfident(): Boolean = confidence >= 0.7f
    }

    /**
     * 🚀 نقطة الدخول الرئيسية — تستخدم Thread + Handler (بدل Coroutines)
     */
    fun processVoiceCommand(
        context: Context,
        voiceText: String,
        onResult: (VoiceAction) -> Unit,
        onError: (String) -> Unit
    ) {
        // 1️⃣ التحقق من الكاش أولاً
        val cached = responseCache[voiceText.lowercase().trim()]
        if (cached != null && cached.isValid()) {
            android.util.Log.d("GeminiVoice", "🗃️ Cache hit: $voiceText")
            onResult(cached.action)
            return
        }

        // 2️⃣ المحاولة الأولى: VoiceCommandParser (مجاني/فوري)
        val parsed = VoiceCommandParser.parse(voiceText)
        if (parsed != VoiceCommand.Unknown) {
            val action = convertToGeminiAction(parsed)
            cacheAndReturn(voiceText, action, onResult)
            return
        }
        
        // 3️⃣ المحاولة الثانية: Gemini (الذكي — يفهم الدارجة)
        if (API_KEY.isBlank()) {
            onError("مفتاح Gemini غير مضبوط. اذهب للإعدادات وأضف API Key.")
            return
        }

        // Thread + Handler بدل Coroutines (للتوافق مع المشروع)
        Thread {
            try {
                val action = callGeminiAPI(voiceText)
                Handler(Looper.getMainLooper()).post {
                    cacheAndReturn(voiceText, action, onResult)
                }
            } catch (e: QuotaExceededException) {
                Handler(Looper.getMainLooper()).post {
                    onError("⚠️ حدود Gemini اليومية انتهت. جرب غداً أو فعّل الخطة المدفوعة.")
                }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post {
                    android.util.Log.e("GeminiVoice", "Error", e)
                    onError("خطأ في Gemini: ${e.localizedMessage}")
                }
            }
        }.start()
    }

    /**
     * 📞 استدعاء Gemini API مع prompt محسّن للدارجة الجزائرية
     */
    private fun callGeminiAPI(voiceText: String): VoiceAction {
        val prompt = buildDarjaPrompt(voiceText)

        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$API_KEY"
        )
        val connection = url.openConnection() as HttpURLConnection

        connection.apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            doOutput = true
            connectTimeout = TIMEOUT_MS
            readTimeout = TIMEOUT_MS
        }

        val requestBody = JSONObject().apply {
            put("contents", org.json.JSONArray().put(JSONObject().apply {
                put("parts", org.json.JSONArray().put(JSONObject().apply {
                    put("text", prompt)
                }))
            }))
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 256)
                put("temperature", 0.1)  // منخفض جداً — نريد دقة لا إبداع
                put("responseMimeType", "application/json")
            })
        }

        connection.outputStream.write(requestBody.toString().toByteArray())
        connection.outputStream.flush()

        val responseCode = connection.responseCode

        // 429 = Quota exceeded
        if (responseCode == 429) {
            throw QuotaExceededException()
        }

        if (responseCode != HttpURLConnection.HTTP_OK) {
            val error = connection.errorStream?.bufferedReader()?.readText() ?: "HTTP $responseCode"
            throw Exception("API Error: $error")
        }

        val response = connection.inputStream.bufferedReader().readText()
        return parseGeminiResponse(response, voiceText)
    }

    /**
     * 📝 بناء Prompt متخصص في الدارجة الجزائرية
     */
    private fun buildDarjaPrompt(voiceText: String): String {
        return """
أنت مساعد صوتي ذكي لتطبيق IPTV جزائري. المستخدم يتكلم بالدارجة الجزائرية (أو العربية الفصحى أو الفرنسية أو الإنجليزية).

تحلل الجملة التالية وتُرجع **JSON فقط** بدون أي نص آخر:

"""${voiceText}"""

أنواع الأوامر الممكنة في التطبيق:
1. **play** — تشغيل قناة أو فيلم أو مسلسل ("شغل beIN Sport", "دير العارضة", "play MBC", "lancer Canal+")
2. **navigate** — الانتقال لصفحة ("روح للإعدادات", "bghit nmchi l settings", "allez à matchs", "مباريات اليوم")
3. **search** — البحث ("حوسلي على فيلم رعب", "chercher film action", "دور على نتفليكس")
4. **control** — التحكم في المشغل ("وقف", "stop", "kemel", ".volume up", "صوت اكثر")
5. **info** — معلومات ("اش حال بقا من الاشتراك", "quand expire")
6. **unknown** — ما فهمتش

**قواعد مهمة:**
- "دير" / "شغل" / "لنش" / "play" / "lancer" = تشغيل
- "روح" / "nmchi" / "allez" / "go" = تنقل
- "حوس" / "دور" / "chercher" / "search" = بحث
- "وقف" / "stop" / " pause" = توقف
- "مباراة" / "match" / "كورة" = مباريات اليوم
- "قناة" / "chaine" / "channel" = بث مباشر
- "فيلم" / "film" / "movie" = أفلام
- "مسلسل" / "série" / "series" = مسلسلات

**رجع JSON بالضبط بهذا الشكل:**
```json
{
  "actionType": "play|navigate|search|control|info|unknown",
  "target": "اسم القناة أو الفيلم أو المسلسل",
  "screen": "live|movies|series|matches|settings|users|prayer|pricing|about|null",
  "extra": "معلومات إضافية مثل نوع الفيلم أو اللغة",
  "confidence": 0.95
}
```

إذا كان الأمر غير واضح، confidence يكون منخفض (< 0.5).
""".trimIndent()
    }

    /**
     * 🔍 تحليل رد Gemini
     */
    private fun parseGeminiResponse(response: String, originalText: String): VoiceAction {
        return try {
            val json = JSONObject(response)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return fallbackAction(originalText)
            }

            val content = candidates.getJSONObject(0)
                .optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (parts == null || parts.length() == 0) {
                return fallbackAction(originalText)
            }

            val text = parts.getJSONObject(0).optString("text", "")

            // Gemini أحياناً يضع JSON داخل markdown
            val cleanJson = text
                .replace("```json", "")
                .replace("```", "")
                .trim()

            val actionJson = JSONObject(cleanJson)

            VoiceAction(
                actionType = actionJson.optString("actionType", "unknown"),
                target = actionJson.optString("target", ""),
                screen = actionJson.optString("screen", null),
                extra = actionJson.optString("extra", ""),
                confidence = actionJson.optDouble("confidence", 0.0).toFloat()
            )
        } catch (e: Exception) {
            android.util.Log.e("GeminiVoice", "Parse error: ${e.message}")
            fallbackAction(originalText)
        }
    }

    /**
     * 🔄 تحويل VoiceCommandParser → VoiceAction
     */
    private fun convertToGeminiAction(parsed: VoiceCommand): VoiceAction {
        return when (parsed) {
            is VoiceCommand.Play -> VoiceAction(
                actionType = "play",
                target = parsed.channelName,
                screen = null,
                extra = "",
                confidence = 0.95f
            )
            is VoiceCommand.Navigate -> VoiceAction(
                actionType = "navigate",
                target = "",
                screen = when (parsed.screen) {
                    VoiceCommand.Screen.LIVE -> "live"
                    VoiceCommand.Screen.MOVIES -> "movies"
                    VoiceCommand.Screen.SERIES -> "series"
                    VoiceCommand.Screen.MATCHES -> "matches"
                    VoiceCommand.Screen.SETTINGS -> "settings"
                    VoiceCommand.Screen.USERS -> "users"
                    VoiceCommand.Screen.PRICING -> "pricing"
                    VoiceCommand.Screen.PRAYER -> "prayer"
                    VoiceCommand.Screen.ABOUT -> "about"
                },
                extra = "",
                confidence = 0.95f
            )
            is VoiceCommand.Search -> VoiceAction(
                actionType = "search",
                target = parsed.query,
                screen = null,
                extra = "",
                confidence = 0.9f
            )
            VoiceCommand.Unknown -> fallbackAction("")
        }
    }

    private fun fallbackAction(text: String): VoiceAction {
        return VoiceAction(
            actionType = "unknown",
            target = text,
            screen = null,
            extra = "",
            confidence = 0.0f
        )
    }

    private fun cacheAndReturn(
        voiceText: String,
        action: VoiceAction,
        onResult: (VoiceAction) -> Unit
    ) {
        responseCache[voiceText.lowercase().trim()] = CachedResponse(action)
        onResult(action)
    }

    /**
     * 🔧 ضبط مفتاح API (من الإعدادات أو BuildConfig)
     */
    fun setApiKey(key: String) {
        API_KEY = key
    }

    /**
     * 🧹 تنظيف الكاش القديم (يُستدعى أسبوعياً)
     */
    fun cleanupCache() {
        val now = System.currentTimeMillis()
        responseCache.entries.removeAll { (now - it.value.timestamp) > CACHE_TTL_MS }
    }

    class QuotaExceededException : Exception("Gemini API quota exceeded")
}
