package com.latchi.iptv.utils

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import com.latchi.iptv.R
import com.latchi.iptv.model.Channel

/**
 * 🎙️ AI Voice Handler - التعرف على الصوت برمجياً بدون نافذة جوجل المنبثقة
 * يستخدم SpeechRecognizer API مباشرة في الخلفية
 */
class VoiceHandler(
    private val context: Context,
    private val voiceOverlay: FrameLayout,
    private val onCommand: (VoiceCommand) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false

    private val glowContainer: View by lazy { voiceOverlay.findViewById(R.id.voiceGlowContainer) }
    private val statusText: TextView by lazy { voiceOverlay.findViewById(R.id.voiceStatusText) }
    private val micIcon: TextView by lazy { voiceOverlay.findViewById(R.id.voiceMicIcon) }

    init {
        voiceOverlay.setOnClickListener { cancelListening() }
    }

    /**
     * بدء الاستماع - يظهر الواجهة السفلية ويبدأ التعرف على الصوت
     */
    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Toast.makeText(context, "التعرف على الصوت غير متوفر على هذا الجهاز", Toast.LENGTH_SHORT).show()
            return
        }

        if (isListening) return
        isListening = true

        showOverlay()
        initSpeechRecognizer()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // ❌ ممنوع: EXTRA_PROMPT أو أي إعداد يظهر نافذة منبثقة
        }

        speechRecognizer?.startListening(intent)
    }

    /**
     * إيقاف الاستماع وإخفاء الواجهة
     */
    fun stopListening() {
        if (!isListening) return
        isListening = false

        speechRecognizer?.stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null

        hideOverlay()
    }

    /**
     * إلغاء الاستماع (عند ضغط المستخدم على الواجهة)
     */
    private fun cancelListening() {
        stopListening()
    }

    private fun showOverlay() {
        voiceOverlay.visibility = View.VISIBLE
        statusText.text = "استمع..."
        micIcon.text = "🎙️"

        // بدء أنيميشن النبض
        val pulseAnim = AnimationUtils.loadAnimation(context, R.anim.voice_pulse)
        glowContainer.startAnimation(pulseAnim)
    }

    private fun hideOverlay() {
        glowContainer.clearAnimation()
        voiceOverlay.visibility = View.GONE
    }

    private fun initSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    statusText.text = "استمع..."
                }

                override fun onBeginningOfSpeech() {
                    statusText.text = "يسمع..."
                }

                override fun onRmsChanged(rmsdB: Float) {
                    // يمكن استخدام مستوى الصوت لتغيير شدة التوهج
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    statusText.text = "يعالج..."
                }

                override fun onError(error: Int) {
                    val message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "لم أفهم، حاول مرة أخرى"
                        SpeechRecognizer.ERROR_NETWORK -> "مشكلة في الاتصال"
                        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "انتهى الوقت"
                        SpeechRecognizer.ERROR_AUDIO -> "مشكلة في الميكروفون"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم يتم التقاط صوت"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "صلاحيات الميكروفون غير ممنوحة"
                        else -> "خطأ في التعرف ($error)"
                    }
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    stopListening()
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val bestMatch = matches[0]
                        handleResult(bestMatch)
                    } else {
                        Toast.makeText(context, "لم يتم التعرف على صوت", Toast.LENGTH_SHORT).show()
                    }
                    stopListening()
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!partial.isNullOrEmpty()) {
                        statusText.text = partial[0]
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun handleResult(text: String) {
        val command = VoiceCommandParser.parse(text)
        onCommand(command)
    }

    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}

/**
 * أنواع أوامر الصوت المدعومة
 */
sealed class VoiceCommand {
    data class Play(val channelName: String) : VoiceCommand()
    data class Navigate(val screen: Screen) : VoiceCommand()
    data class Search(val query: String) : VoiceCommand()
    object Unknown : VoiceCommand()

    enum class Screen {
        SETTINGS, MATCHES, MOVIES, SERIES, LIVE, USERS, PRICING, PRAYER, ABOUT
    }
}
