package com.latchi.iptv.utils

import com.latchi.iptv.model.Channel

/**
 * 🎙️ محلل أوامر الصوت - يفرّق بين التشغيل والتنقل والبحث
 */
object VoiceCommandParser {

    private val NAVIGATION_KEYWORDS = mapOf(
        listOf("إعدادات", "settings", "اعدادات", "setting", "الإعدادات", "الاعدادات") to VoiceCommand.Screen.SETTINGS,
        listOf("مباريات", "matches", "match", "المباريات", "مباراة", "كورة", "كرة") to VoiceCommand.Screen.MATCHES,
        listOf("أفلام", "movies", "movie", "الأفلام", "افلام", "الافلام", "film", "films") to VoiceCommand.Screen.MOVIES,
        listOf("مسلسلات", "series", "مسلسل", "المسلسلات", "الحلقات") to VoiceCommand.Screen.SERIES,
        listOf("قنوات", "قناة", "مباشر", "live", "channels", "channel", "tv", "تلفزيون") to VoiceCommand.Screen.LIVE,
        listOf("مستخدم", "users", "user", "المستخدمين", "تغيير", "حساب", "account") to VoiceCommand.Screen.USERS,
        listOf("تسعير", "pricing", "الأسعار", "الاسعار", "سعر", "اشتراك") to VoiceCommand.Screen.PRICING,
        listOf("صلاة", "صلا", "prayer", "prayers", "مواقيت", "أذان") to VoiceCommand.Screen.PRAYER,
        listOf("حول", "عن", "about", "معلومات", "info") to VoiceCommand.Screen.ABOUT
    )

    private val PLAY_KEYWORDS = listOf(
        "شغل", "تشغيل", "play", "افتح", "open", "عرض", "show", "شوف", "watch"
    )

    fun parse(voiceText: String): VoiceCommand {
        val text = voiceText.lowercase().trim()

        for ((keywords, screen) in NAVIGATION_KEYWORDS) {
            if (keywords.any { text.contains(it) }) return VoiceCommand.Navigate(screen)
        }

        for (keyword in PLAY_KEYWORDS) {
            if (text.startsWith(keyword) || text.contains(" $keyword ")) {
                val targetName = text.replace(keyword, "").trim()
                if (targetName.isNotEmpty()) return VoiceCommand.Play(targetName)
            }
        }

        if (text.length <= 30 && text.split(" ").size <= 4) return VoiceCommand.Play(text)

        return VoiceCommand.Search(text)
    }
}

/**
 * 📋 On-Demand Voice Matching Engine
 * Fully RAM-efficient. Zero heap locks.
 */
object VoiceIndex {
    private var channels: List<Channel> = emptyList()

    @Synchronized
    fun update(newChannels: List<Channel>) {
        channels = newChannels
    }

    fun findChannel(query: String): Channel? {
        val normalized = query.lowercase().trim()
        val list = channels
        if (list.isEmpty() || normalized.isEmpty()) return null

        list.firstOrNull { it.name.lowercase().trim() == normalized }?.let { return it }

        list.firstOrNull { ch ->
            val lower = ch.name.lowercase().trim()
            lower.contains(normalized) || normalized.contains(lower)
        }?.let { return it }

        val queryWords = normalized.split(" ", "-", "_", ".").filter { it.length >= 3 }
        for (word in queryWords) {
            list.firstOrNull { it.name.lowercase().contains(word) }?.let { return it }
        }

        if (normalized.length >= 3) {
            val prefix = normalized.take(3)
            list.firstOrNull { it.name.lowercase().startsWith(prefix) }?.let { return it }
        }

        return null
    }

    fun getAll(): List<Channel> = channels
    fun isEmpty(): Boolean = channels.isEmpty()
}
