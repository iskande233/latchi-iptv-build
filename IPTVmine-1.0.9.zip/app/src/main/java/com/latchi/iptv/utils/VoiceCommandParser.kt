package com.latchi.iptv.utils

import com.latchi.iptv.model.Channel

/**
 * 🎙️ محلل أوامر الصوت - يفرّق بين التشغيل والتنقل والبحث
 */
object VoiceCommandParser {

    // 🔤 كلمات مفتاحية للتنقل
    private val NAVIGATION_KEYWORDS = mapOf(
        // الإعدادات
        listOf("إعدادات", "settings", "اعدادات", "setting", "الإعدادات", "الاعدادات") to VoiceCommand.Screen.SETTINGS,
        // المباريات
        listOf("مباريات", "matches", "match", "المباريات", "مباراة", "كورة", "كرة") to VoiceCommand.Screen.MATCHES,
        // الأفلام
        listOf("أفلام", "movies", "movie", "الأفلام", "افلام", "الافلام", "film", "films") to VoiceCommand.Screen.MOVIES,
        // المسلسلات
        listOf("مسلسلات", "series", "مسلسل", "المسلسلات", "الحلقات") to VoiceCommand.Screen.SERIES,
        // البث المباشر
        listOf("قنوات", "قناة", "مباشر", "live", "channels", "channel", "tv", "تلفزيون") to VoiceCommand.Screen.LIVE,
        // تغيير المستخدم
        listOf("مستخدم", "users", "user", "المستخدمين", "تغيير", "حساب", "account") to VoiceCommand.Screen.USERS,
        // التسعير
        listOf("تسعير", "pricing", "الأسعار", "الاسعار", "سعر", "اشتراك") to VoiceCommand.Screen.PRICING,
        // أوقات الصلاة
        listOf("صلاة", "صلا", "prayer", "prayers", "مواقيت", "أذان") to VoiceCommand.Screen.PRAYER,
        // حول التطبيق
        listOf("حول", "عن", "about", "معلومات", "info") to VoiceCommand.Screen.ABOUT
    )

    // 🔤 كلمات مفتاحية للتشغيل
    private val PLAY_KEYWORDS = listOf(
        "شغل", "تشغيل", "play", "افتح", "open", "عرض", "show", "شوف", "watch"
    )

    /**
     * تحليل نص الصوت إلى أمر VoiceCommand
     */
    fun parse(voiceText: String): VoiceCommand {
        val text = voiceText.lowercase().trim()

        // 1️⃣ التحقق من أوامر التنقل أولاً
        for ((keywords, screen) in NAVIGATION_KEYWORDS) {
            if (keywords.any { text.contains(it) }) {
                return VoiceCommand.Navigate(screen)
            }
        }

        // 2️⃣ التحقق من أوامر التشغيل
        for (keyword in PLAY_KEYWORDS) {
            if (text.startsWith(keyword) || text.contains(" $keyword ")) {
                val targetName = text.replace(keyword, "").trim()
                if (targetName.isNotEmpty()) {
                    return VoiceCommand.Play(targetName)
                }
            }
        }

        // 3️⃣ إذا كان النص قصير (اسم قناة محتمل) ولم يتطابق مع شيء آخر
        if (text.length <= 30 && text.split(" ").size <= 4) {
            // ربما يقول اسم قناة مباشرة بدون "شغل"
            return VoiceCommand.Play(text)
        }

        // 4️⃣ بحث عادي
        return VoiceCommand.Search(text)
    }
}

/**
 * 📋 فهرس القنوات المسبق - للبحث الفوري
 */
object VoiceIndex {
    private var channels: List<Channel> = emptyList()
    private var nameIndex: Map<String, Channel> = emptyMap()
    private var wordIndex: Map<String, List<Channel>> = emptyMap()

    @Synchronized
    fun update(newChannels: List<Channel>) {
        channels = newChannels
        nameIndex = newChannels.associateBy { it.name.lowercase() }

        // فهرسة الكلمات الفردية للبحث التقريبي
        val wordMap = mutableMapOf<String, MutableList<Channel>>()
        for (channel in newChannels) {
            val words = channel.name.lowercase().split(" ", "-", "_", ".", "|", "/")
            for (word in words) {
                if (word.length >= 2) {
                    wordMap.getOrPut(word) { mutableListOf() }.add(channel)
                }
            }
        }
        wordIndex = wordMap
    }

    /**
     * البحث الفوري عن قناة بالاسم (دقيق أو تقريبي)
     */
    fun findChannel(query: String): Channel? {
        val normalized = query.lowercase().trim()

        // 1️⃣ تطابق دقيق
        nameIndex[normalized]?.let { return it }

        // 2️⃣ تطابق جزئي في الاسم الكامل
        channels.firstOrNull { ch ->
            ch.name.lowercase().contains(normalized) || normalized.contains(ch.name.lowercase())
        }?.let { return it }

        // 3️⃣ تطابق كلمة فردية
        val queryWords = normalized.split(" ", "-", "_", ".")
        for (word in queryWords) {
            if (word.length >= 2) {
                wordIndex[word]?.let { candidates ->
                    // ارجع أفضل تطابق
                    candidates.firstOrNull()?.let { return it }
                }
            }
        }

        // 4️⃣ تطابق تقريبي (أول 3 حروف)
        if (normalized.length >= 3) {
            channels.firstOrNull { ch ->
                ch.name.lowercase().startsWith(normalized.take(3))
            }?.let { return it }
        }

        return null
    }

    fun getAll(): List<Channel> = channels
    fun isEmpty(): Boolean = channels.isEmpty()
}
