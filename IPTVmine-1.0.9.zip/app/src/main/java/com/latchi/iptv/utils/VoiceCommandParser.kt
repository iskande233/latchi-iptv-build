package com.latchi.iptv.utils

import com.latchi.iptv.model.Channel

/**
 * 🎙️ محلل أوامر الصوت - يفرّق بين التشغيل والتنقل والبحث
 */
object VoiceCommandParser {

    // 🔤 كلمات مفتاحية للتنقل
    private val NAVIGATION_KEYWORDS = mapOf(
        // الإعدادات
        listOf("إعدادات", "settings", "اعدادات", "setting", "الإعدادات", "الاعدادات") to VoiceCommand.Screen.SETTINGS,
        // المباريات
        listOf("مباريات", "matches", "match", "المباريات", "مباراة", "كورة", "كرة") to VoiceCommand.Screen.MATCHES,
        // الأفلام
        listOf("أفلام", "movies", "movie", "الأفلام", "افلام", "الافلام", "film", "films") to VoiceCommand.Screen.MOVIES,
        // المسلسلات
        listOf("مسلسلات", "series", "مسلسل", "المسلسلات", "الحلقات") to VoiceCommand.Screen.SERIES,
        // البث المباشر
        listOf("قنوات", "قناة", "مباشر", "live", "channels", "channel", "tv", "تلفزيون") to VoiceCommand.Screen.LIVE,
        // تغيير المستخدم
        listOf("مستخدم", "users", "user", "المستخدمين", "تغيير", "حساب", "account") to VoiceCommand.Screen.USERS,
        // التسعير
        listOf("تسعير", "pricing", "الأسعار", "الاسعار", "سعر", "اشتراك") to VoiceCommand.Screen.PRICING,
        // أوقات الصلاة
        listOf("صلاة", "صلا", "prayer", "prayers", "مواقيت", "أذان") to VoiceCommand.Screen.PRAYER,
        // حول التطبيق
        listOf("حول", "عن", "about", "معلومات", "info") to VoiceCommand.Screen.ABOUT
    )

    // 🔤 كلمات مفتاحية للتشغيل
    private val PLAY_KEYWORDS = listOf(
        "شغل", "تشغيل", "play", "افتح", "open", "عرض", "show", "شوف", "watch"
    )

    /**
     * تحليل نص الصوت إلى أمر VoiceCommand
     */
    fun parse(voiceText: String): VoiceCommand {
        val text = voiceText.lowercase().trim()

        // 1️⃣ التحقق من أوامر التنقل أولاً
        for ((keywords, screen) in NAVIGATION_KEYWORDS) {
            if (keywords.any { text.contains(it) }) {
                return VoiceCommand.Navigate(screen)
            }
        }

        // 2️⃣ التحقق من أوامر التشغيل
        for (keyword in PLAY_KEYWORDS) {
            if (text.startsWith(keyword) || text.contains(" $keyword ")) {
                val targetName = text.replace(keyword, "").trim()
                if (targetName.isNotEmpty()) {
                    return VoiceCommand.Play(targetName)
                }
            }
        }

        // 3️⃣ إذا كان النص قصير (اسم قناة محتمل) ولم يتطابق مع شيء آخر
        if (text.length <= 30 && text.split(" ").size <= 4) {
            // ربما يقول اسم قناة مباشرة بدون "شغل"
            return VoiceCommand.Play(text)
        }

        // 4️⃣ بحث عادي
        return VoiceCommand.Search(text)
    }
}

/**
 * 📋 فهرس القنوات المسبق - للبحث الفوري (مُحسّن وخفيف جداً ليعمل على التلفاز بدون OutOfMemory)
 */
object VoiceIndex {
    private var channels: List<Channel> = emptyList()

    @Synchronized
    fun update(newChannels: List<Channel>) {
        // نكتفي بتخزين المرجع فقط (0 استهلاك للذاكرة، 0 استهلاك للمعالج)
        channels = newChannels
    }

    /**
     * البحث الفوري عن قناة بالاسم (دقيق أو تقريبي)
     */
    fun findChannel(query: String): Channel? {
        val normalized = query.lowercase().trim()
        val list = channels
        if (list.isEmpty() || normalized.isEmpty()) return null

        // 1️⃣ تطابق دقيق
        list.firstOrNull { it.name.lowercase().trim() == normalized }?.let { return it }

        // 2️⃣ تطابق جزئي في الاسم الكامل
        list.firstOrNull { ch ->
            val lower = ch.name.lowercase().trim()
            lower.contains(normalized) || normalized.contains(lower)
        }?.let { return it }

        // 3️⃣ تطابق كلمة فردية مهمة (طولها >= 3)
        val queryWords = normalized.split(" ", "-", "_", ".").filter { it.length >= 3 }
        for (word in queryWords) {
            list.firstOrNull { it.name.lowercase().contains(word) }?.let { return it }
        }

        // 4️⃣ تطابق تقريبي (أول 3 حروف)
        if (normalized.length >= 3) {
            val prefix = normalized.take(3)
            list.firstOrNull { it.name.lowercase().startsWith(prefix) }?.let { return it }
        }

        return null
    }

    fun getAll(): List<Channel> = channels
    fun isEmpty(): Boolean = channels.isEmpty()
}
