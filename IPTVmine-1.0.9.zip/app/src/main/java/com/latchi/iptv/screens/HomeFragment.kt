package com.latchi.iptv.screens

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R
import com.latchi.iptv.adapter.UserProfilesAdapter
import com.latchi.iptv.model.Channel
import com.latchi.iptv.provider.ChannelsProvider
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.DateText
import com.latchi.iptv.utils.LastWatchedPrefs
import com.latchi.iptv.utils.SourcePrefs
import com.latchi.iptv.utils.VoiceCommand
import com.latchi.iptv.utils.VoiceHandler
import com.latchi.iptv.utils.VoiceIndex
import com.latchi.iptv.utils.GeminiVoiceController
import android.widget.FrameLayout
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.Manifest
import android.net.Uri

class HomeFragment : Fragment() {
    private lateinit var channelsProvider: ChannelsProvider
    private lateinit var cardLive: LinearLayout
    private lateinit var cardMovies: LinearLayout
    private lateinit var cardSeries: LinearLayout
    private lateinit var cardMatches: LinearLayout
    private lateinit var cardChangeUser: LinearLayout
    private lateinit var cardUpdate: LinearLayout
    private lateinit var cardSettings: LinearLayout
    private lateinit var lastWatchedButton: TextView
    private lateinit var whatsappButton: LinearLayout
    private lateinit var liveCount: TextView
    private lateinit var movieCount: TextView
    private lateinit var seriesCount: TextView
    private lateinit var updatedText: TextView
    private lateinit var loggedInText: TextView
    private lateinit var expiryText: TextView
    private lateinit var progressBar: android.view.View
    private lateinit var loadingOverlay: View
    private lateinit var usersRecyclerView: RecyclerView
    private lateinit var usersAdapter: UserProfilesAdapter
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var backToHomeButton: LinearLayout
    private lateinit var toolbarSettings: LinearLayout
    private lateinit var toolbarUsers: LinearLayout
    private var cardAIVoice: LinearLayout? = null
    private var voiceOverlay: FrameLayout? = null
    private var voiceHandler: VoiceHandler? = null
    private var saveAfterFetch = false
    private var loadingTimeoutHandler: android.os.Handler? = null
    private var adhkarRotatorHandler: Handler? = null
    private var adhkarRotatorRunnable: Runnable? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        channelsProvider = ViewModelProvider(this)[ChannelsProvider::class.java]
        cardLive = view.findViewById(R.id.cardLive)
        cardMovies = view.findViewById(R.id.cardMovies)
        cardSeries = view.findViewById(R.id.cardSeries)
        cardMatches = view.findViewById(R.id.cardMatches)
        backToHomeButton = view.findViewById(R.id.backToHomeButton)
        toolbarSettings = view.findViewById(R.id.toolbarSettings)
        toolbarUsers = view.findViewById(R.id.toolbarUsers)
        cardAIVoice = view.findViewById(R.id.cardAIVoice) // nullable - may be missing on phone layout
        voiceOverlay = view.findViewById(R.id.voiceOverlay) // nullable - may be missing on phone layout
        lastWatchedButton = view.findViewById(R.id.lastWatchedButton)
        whatsappButton = view.findViewById(R.id.whatsappButton)
        liveCount = view.findViewById(R.id.liveCount)
        movieCount = view.findViewById(R.id.movieCount)
        seriesCount = view.findViewById(R.id.seriesCount)
        updatedText = view.findViewById(R.id.updatedText)
        loggedInText = view.findViewById(R.id.loggedInText)
        expiryText = view.findViewById(R.id.expiryText)
        progressBar = view.findViewById(R.id.loadingRow)
        loadingOverlay = view.findViewById(R.id.loadingOverlay)
        usersRecyclerView = view.findViewById(R.id.usersRecyclerView)
        drawerLayout = view.findViewById(R.id.drawerLayout)

        setupDrawer(view)
        setupUsersRecycler()
        setupVoiceHandler()
        setupClicks(view)
        // 📅 التاريخ الميلادي اليومي (واجهة TV الملكية)
        view.findViewById<TextView?>(R.id.tvDateText)?.let { dateView ->
            try {
                val sdf = java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale("ar"))
                dateView.text = "📅 " + sdf.format(java.util.Date())
            } catch (_: Exception) { }
        }
        checkUpdateBadge(view)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupObservers()
        loadCachedOrFetch()
        animateUi(view)
    }

    private fun setupDrawer(view: View) {
        view.findViewById<TextView>(R.id.menuButton).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.END)
        }
        view.findViewById<TextView>(R.id.drawerMatches).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), MatchesActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerPrayer).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), PrayerActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerPricing).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), PricingActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerThemeSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), ThemeSettingsActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerAbout).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            showAboutDialog()
        }
        view.findViewById<android.widget.TextView?>(R.id.drawerShare)?.setOnClickListener { drawerLayout.closeDrawer(androidx.core.view.GravityCompat.END); val si = Intent(Intent.ACTION_SEND); si.type = "text/plain"; si.putExtra(Intent.EXTRA_TEXT, "LATCHI IPTV"); startActivity(Intent.createChooser(si, "Share")) }
    }

    private fun showAboutDialog() {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.app_info_title))
            .setMessage(getString(R.string.app_info_desc))
            .setPositiveButton(getString(R.string.close), null)
            .show()
    }

    private fun setupUsersRecycler() {
        usersAdapter = UserProfilesAdapter(
            emptyList(),
            onOpen = { profile ->
                SourcePrefs.setActiveProfile(requireContext(), profile.id)
                requireActivity().recreate()
            },
            onDelete = { profile ->
                SourcePrefs.deleteProfile(requireContext(), profile.id)
                refreshUsers()
            }
        )
        usersRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        usersRecyclerView.adapter = usersAdapter
        refreshUsers()
    }

    private fun refreshUsers() {
        val profiles = SourcePrefs.getProfiles(requireContext())
        usersAdapter.update(profiles)
        usersRecyclerView.visibility = if (profiles.size > 1) View.VISIBLE else View.GONE
    }

    private fun animateUi(root: View) {
        try {
            val ctx = root.context
            root.findViewById<View?>(R.id.headerLogo)?.startAnimation(
                android.view.animation.AnimationUtils.loadAnimation(ctx, R.anim.float_updown)
            )
            val cards = listOf(R.id.cardLive, R.id.cardMovies, R.id.cardSeries, R.id.cardMatches)
            cards.forEachIndexed { index, id ->
                root.findViewById<View?>(id)?.let { card ->
                    val anim = android.view.animation.AnimationUtils.loadAnimation(ctx, R.anim.card_slide_up)
                    anim.startOffset = (index * 90).toLong()
                    card.startAnimation(anim)
                }
            }
        } catch (_: Exception) { }
    }

    private fun setupClicks(view: View) {
        cardLive.setOnClickListener { ChannelListActivity.start(requireContext(), "live", getString(R.string.live_tv)) }
        cardMovies.setOnClickListener { ChannelListActivity.start(requireContext(), "movie", getString(R.string.movies)) }
        cardSeries.setOnClickListener { ChannelListActivity.start(requireContext(), "series", getString(R.string.series)) }
        cardMatches.setOnClickListener { startActivity(Intent(requireContext(), MatchesActivity::class.java)) }
        backToHomeButton.setOnClickListener {
            startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
            requireActivity().finish()
        }
        view.findViewById<android.widget.LinearLayout?>(R.id.toolbarSettingsTop)?.setOnClickListener { startActivity(Intent(requireContext(), SettingsActivity::class.java)) }
        view.findViewById<android.widget.LinearLayout?>(R.id.toolbarUsersTop)?.setOnClickListener { forceUpdate() }
        toolbarSettings.setOnClickListener { startActivity(Intent(requireContext(), SettingsActivity::class.java)) }
        toolbarUsers.setOnClickListener {
            startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
            requireActivity().finish()
        }
        cardAIVoice?.setOnClickListener { onAIVoiceClicked() }
        lastWatchedButton.setOnClickListener { openLastWatched() }
        whatsappButton.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/213798712450")))
            } catch (_: Exception) { }
        }
    }

    private fun setupVoiceHandler() {
        val overlay = voiceOverlay ?: return
        voiceHandler = VoiceHandler(
            context = requireContext(),
            voiceOverlay = overlay,
            onCommand = { command: com.latchi.iptv.utils.VoiceCommand -> handleVoiceCommand(command) },
            onGeminiAction = { action: com.latchi.iptv.utils.GeminiVoiceController.VoiceAction -> handleGeminiAction(action) }
        )
    }

    private fun onAIVoiceClicked() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), VOICE_REQUEST_CODE)
            return
        }
        voiceHandler?.startListening()
    }

    companion object {
        private const val VOICE_REQUEST_CODE = 2026
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == VOICE_REQUEST_CODE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            voiceHandler?.startListening()
        } else {
            Toast.makeText(requireContext(), "صلاحية الميكروفون مطلوبة للبحث الصوتي", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleVoiceCommand(command: VoiceCommand) {
        when (command) {
            is VoiceCommand.Play -> {
                val channel = VoiceIndex.findChannel(command.channelName)
                if (channel != null) {
                    val intent = Intent(requireContext(), PlayerActivity::class.java)
                    intent.putExtra("channel", channel)
                    startActivity(intent)
                } else {
                    Toast.makeText(requireContext(), "لم أجد قناة: ${command.channelName}", Toast.LENGTH_SHORT).show()
                    val intent = Intent(requireContext(), ChannelListActivity::class.java)
                    intent.putExtra("type", "live")
                    intent.putExtra("title", getString(R.string.live_tv))
                    intent.putExtra("search_query", command.channelName)
                    startActivity(intent)
                }
            }
            is VoiceCommand.Navigate -> {
                when (command.screen) {
                    VoiceCommand.Screen.SETTINGS -> startActivity(Intent(requireContext(), SettingsActivity::class.java))
                    VoiceCommand.Screen.MATCHES -> startActivity(Intent(requireContext(), MatchesActivity::class.java))
                    VoiceCommand.Screen.MOVIES -> ChannelListActivity.start(requireContext(), "movie", getString(R.string.movies))
                    VoiceCommand.Screen.SERIES -> ChannelListActivity.start(requireContext(), "series", getString(R.string.series))
                    VoiceCommand.Screen.LIVE -> ChannelListActivity.start(requireContext(), "live", getString(R.string.live_tv))
                    VoiceCommand.Screen.USERS -> {
                        startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
                        requireActivity().finish()
                    }
                    VoiceCommand.Screen.PRICING -> startActivity(Intent(requireContext(), PricingActivity::class.java))
                    VoiceCommand.Screen.PRAYER -> startActivity(Intent(requireContext(), PrayerActivity::class.java))
                    VoiceCommand.Screen.ABOUT -> showAboutDialog()
                }
            }
            is VoiceCommand.Search -> {
                Toast.makeText(requireContext(), "بحث عن: ${command.query}", Toast.LENGTH_SHORT).show()
                val intent = Intent(requireContext(), ChannelListActivity::class.java)
                intent.putExtra("type", "live")
                intent.putExtra("title", getString(R.string.live_tv))
                intent.putExtra("search_query", command.query)
                startActivity(intent)
            }
            VoiceCommand.Unknown -> {
                Toast.makeText(requireContext(), "لم أفهم الأمر، حاول مرة أخرى", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * 🧠 Gemini Smart Action Handler — يفهم الدارجة ويتحكم في كل شيء
     */
    private fun handleGeminiAction(action: GeminiVoiceController.VoiceAction) {
        android.util.Log.d("GeminiVoice", "Action: ${action.actionType} → ${action.target} (conf: ${action.confidence})")
        
        if (!action.isConfident()) {
            Toast.makeText(requireContext(), "🤔 لم أكن متأكداً (ثقة: ${(action.confidence * 100).toInt()}%). أعد المحاولة بوضوح.", Toast.LENGTH_SHORT).show()
            return
        }

        when (action.actionType) {
            "play" -> {
                if (action.target.isNotBlank()) {
                    val channel = VoiceIndex.findChannel(action.target)
                    if (channel != null) {
                        Toast.makeText(requireContext(), "▶️ شغل: ${channel.name}", Toast.LENGTH_SHORT).show()
                        val intent = Intent(requireContext(), PlayerActivity::class.java)
                        intent.putExtra("channel", channel)
                        startActivity(intent)
                    } else {
                        Toast.makeText(requireContext(), "🔍 بحث عن: ${action.target}", Toast.LENGTH_SHORT).show()
                        val searchIntent = Intent(requireContext(), ChannelListActivity::class.java)
                        searchIntent.putExtra("type", "all")
                        searchIntent.putExtra("title", "نتائج: ${action.target}")
                        searchIntent.putExtra("search_query", action.target)
                        startActivity(searchIntent)
                    }
                } else {
                    Toast.makeText(requireContext(), "🤔 ما تحب تشغل؟", Toast.LENGTH_SHORT).show()
                }
            }
            "navigate" -> {
                when (action.screen) {
                    "settings" -> startActivity(Intent(requireContext(), SettingsActivity::class.java))
                    "matches" -> startActivity(Intent(requireContext(), MatchesActivity::class.java))
                    "movies" -> ChannelListActivity.start(requireContext(), "movie", getString(R.string.movies))
                    "series" -> ChannelListActivity.start(requireContext(), "series", getString(R.string.series))
                    "live", "tv", "channels" -> ChannelListActivity.start(requireContext(), "live", getString(R.string.live_tv))
                    "users" -> {
                        startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
                        requireActivity().finish()
                    }
                    "pricing" -> startActivity(Intent(requireContext(), PricingActivity::class.java))
                    "prayer" -> startActivity(Intent(requireContext(), PrayerActivity::class.java))
                    "about" -> showAboutDialog()
                    else -> Toast.makeText(requireContext(), "🔍 الانتقال: ${action.screen}", Toast.LENGTH_SHORT).show()
                }
            }
            "search" -> {
                if (action.target.isNotBlank()) {
                    Toast.makeText(requireContext(), "🔍 بحث: ${action.target}", Toast.LENGTH_SHORT).show()
                    val intent = Intent(requireContext(), ChannelListActivity::class.java)
                    intent.putExtra("type", "all")
                    intent.putExtra("title", "بحث: ${action.target}")
                    intent.putExtra("search_query", action.target)
                    startActivity(intent)
                } else {
                    Toast.makeText(requireContext(), "🤔 ما تبغي تبحث عنه؟", Toast.LENGTH_SHORT).show()
                }
            }
            "control" -> {
                Toast.makeText(requireContext(), "🎮 أمر تحكم: ${action.target}", Toast.LENGTH_SHORT).show()
            }
            "info" -> {
                Toast.makeText(requireContext(), "ℹ️ ${action.target}", Toast.LENGTH_SHORT).show()
            }
            "unknown" -> {
                Toast.makeText(requireContext(), "🤔 لم أفهم: \"${action.target}\" — حاول بطريقة أخرى", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(requireContext(), "❓ نوع غير معروف: ${action.actionType}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupObservers() {
        channelsProvider.channels.observe(viewLifecycleOwner, Observer { data ->
            loadingTimeoutHandler?.removeCallbacksAndMessages(null)
            progressBar.visibility = View.GONE
            loadingOverlay.visibility = View.GONE
            stopAdhkarRotator()
            updateCounts(data)
            if (data.isNotEmpty()) {
                VoiceIndex.update(data)
            }
            val active = SourcePrefs.getActiveProfile(requireContext())
            if (saveAfterFetch && active != null && data.isNotEmpty()) {
                ChannelCache.save(requireContext(), active.id, data)
                saveAfterFetch = false
                updateCacheTime(active.id)
                Toast.makeText(requireContext(), getString(R.string.playlist_updated), Toast.LENGTH_SHORT).show()
            }
        })
        channelsProvider.error.observe(viewLifecycleOwner, Observer { error ->
            loadingTimeoutHandler?.removeCallbacksAndMessages(null)
            if (!error.isNullOrBlank()) {
                progressBar.visibility = View.GONE
                loadingOverlay.visibility = View.GONE
                stopAdhkarRotator()
                Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun loadCachedOrFetch() {
        val active = SourcePrefs.getActiveProfile(requireContext())
        if (active == null) { startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true)); requireActivity().finish(); return }
        loggedInText.text = "${getString(R.string.logged_in)}: ${active.name}"
        expiryText.text = "${getString(R.string.expiry)}: ${DateText.shortDate(active.expiresAt)}"
        checkExpiryWarning(active.expiresAt)
        val cached = ChannelCache.load(requireContext(), active.id)
        if (cached.isNotEmpty()) {
            channelsProvider.setLocalChannels(cached)
            updateCacheTime(active.id)
            VoiceIndex.update(cached)
        } else {
            saveAfterFetch = true
            progressBar.visibility = View.VISIBLE
            loadingOverlay.visibility = View.VISIBLE
            startAdhkarRotator()
            startLoadingTimeout()
            channelsProvider.fetchM3UFile(active.m3uUrl)
        }
    }

    private fun checkExpiryWarning(expiresAt: String) {
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val expiryDate = sdf.parse(expiresAt) ?: return
            val diffMillis = expiryDate.time - System.currentTimeMillis()
            val diffDays = (diffMillis / (1000 * 60 * 60 * 24)).toInt()
            if (diffDays in 0..3) {
                val msg = if (diffDays == 0) "⏰ اشتراكك ينتهي اليوم! جدّد الآن"
                          else "⏰ اشتراكك ينتهي بعد $diffDays " + (if (diffDays == 1) "يوم" else "أيام") + "! اضغط للتجديد"
                view?.post {
                    Toast.makeText(requireContext(), getString(R.string.expiry_warning, diffDays), Toast.LENGTH_LONG).show()
                    view?.findViewById<TextView?>(R.id.expiryBanner)?.let { banner ->
                        banner.text = msg
                        banner.visibility = View.VISIBLE
                        banner.setOnClickListener { whatsappButton.performClick() }
                    }
                }
                showExpiryNotification(diffDays)
            }
        } catch (_: Exception) { }
    }

    private fun showExpiryNotification(daysLeft: Int) {
        try {
            val ctx = requireContext()
            val prefs = ctx.getSharedPreferences("expiry_notify", android.content.Context.MODE_PRIVATE)
            val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            if (prefs.getString("last_notified", "") == todayKey) return
            prefs.edit().putString("last_notified", todayKey).apply()

            val channelId = "latchi_expiry"
            val nm = ctx.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                nm.createNotificationChannel(
                    android.app.NotificationChannel(channelId, "تنبيه الاشتراك", android.app.NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val waIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://wa.me/213798712450"))
            val pi = android.app.PendingIntent.getActivity(
                ctx, 7001, waIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val title = if (daysLeft == 0) "⏰ اشتراكك ينتهي اليوم!" else "⏰ اشتراكك ينتهي بعد $daysLeft " + (if (daysLeft == 1) "يوم" else "أيام")
            val notif = androidx.core.app.NotificationCompat.Builder(ctx, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText("اضغط هنا للتجديد عبر واتساب وعدم انقطاع الخدمة 📺")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .build()
            nm.notify(7001, notif)
        } catch (_: Exception) { }
    }

    private fun forceUpdate() {
        val active = SourcePrefs.getActiveProfile(requireContext()) ?: return
        saveAfterFetch = true
        progressBar.visibility = View.VISIBLE
        loadingOverlay.visibility = View.VISIBLE
        startAdhkarRotator()
        startLoadingTimeout()
        channelsProvider.fetchM3UFile(active.m3uUrl)
    }

    private fun startLoadingTimeout() {
        loadingTimeoutHandler?.removeCallbacksAndMessages(null)
        loadingTimeoutHandler = android.os.Handler(android.os.Looper.getMainLooper())
        loadingTimeoutHandler?.postDelayed({
            if (progressBar.visibility == View.VISIBLE) {
                progressBar.visibility = View.GONE
                loadingOverlay.visibility = View.GONE
                stopAdhkarRotator()
                Toast.makeText(requireContext(), "انتهت مهلة التحميل (دقيقتين). اضغط 'تحديث' للمحاولة مرة أخرى.", Toast.LENGTH_LONG).show()
            }
        }, 120000)
    }

    private fun startAdhkarRotator() {
        stopAdhkarRotator()
        val adhkarTexts = resources.getStringArray(R.array.adhkar_items)
        val adhkarRefs = resources.getStringArray(R.array.adhkar_references)
        val ayatTexts = resources.getStringArray(R.array.ayat_items)
        val ayatRefs = resources.getStringArray(R.array.ayat_references)
        val allTexts = adhkarTexts.toList() + ayatTexts.toList()
        val allRefs = adhkarRefs.toList() + ayatRefs.toList()
        val titleView = loadingOverlay.findViewById<TextView?>(R.id.loadingTitle)
        val textView = loadingOverlay.findViewById<TextView?>(R.id.loadingText)
        val refView = loadingOverlay.findViewById<TextView?>(R.id.loadingRef)
        if (titleView != null) titleView.text = getString(R.string.loading_adhkar_title)
        if (allTexts.isEmpty()) return
        adhkarRotatorHandler = Handler(Looper.getMainLooper())
        adhkarRotatorRunnable = object : Runnable {
            override fun run() {
                val idx = (0 until allTexts.size).random()
                textView?.text = allTexts[idx]
                refView?.text = allRefs.getOrNull(idx) ?: ""
                adhkarRotatorHandler?.postDelayed(this, 8000)
            }
        }
        adhkarRotatorHandler?.post(adhkarRotatorRunnable!!)
    }

    private fun stopAdhkarRotator() {
        adhkarRotatorHandler?.removeCallbacksAndMessages(null)
        adhkarRotatorHandler = null
        adhkarRotatorRunnable = null
    }

    private fun updateCounts(data: List<Channel>) {
        liveCount.text = "${data.count { it.contentType == "live" }} ${getString(R.string.channels_suffix)}"
        movieCount.text = "${data.count { it.contentType == "movie" }} ${getString(R.string.movies_suffix)}"
        seriesCount.text = "${data.count { it.contentType == "series" }} ${getString(R.string.series_suffix)}"
    }

    private fun updateCacheTime(profileId: String) {
        val time = ChannelCache.updatedAt(requireContext(), profileId)
        updatedText.text = "${getString(R.string.last_update)}: " + if (time == 0L) "--" else "✓"
    }

    private fun checkUpdateBadge(view: View) {
        val badge = view.findViewById<TextView?>(R.id.updateBadge) ?: return
        com.latchi.iptv.utils.UpdateChecker.checkInBackground(requireActivity(),
            object : com.latchi.iptv.utils.UpdateChecker.OnUpdateListener {
                override fun onUpdateAvailable(versionName: String, notes: String, url: String) {
                    badge.visibility = View.VISIBLE
                    badge.text = "🔄 ${getString(R.string.update_available)} $versionName"
                    badge.setOnClickListener {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                        } catch (_: Exception) { }
                    }
                }
            })
    }

    private fun openLastWatched() {
        val active = SourcePrefs.getActiveProfile(requireContext()) ?: return
        val channel = LastWatchedPrefs.load(requireContext(), active.id)
        if (channel != null) {
            PlayerActivity.start(requireContext(), channel)
        } else {
            Toast.makeText(requireContext(), getString(R.string.no_last_watched), Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        refreshUsers()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        voiceHandler?.destroy()
        voiceHandler = null
        stopAdhkarRotator()
    }
}
