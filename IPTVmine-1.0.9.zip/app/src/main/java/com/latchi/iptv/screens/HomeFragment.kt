package com.latchi.iptv.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R
import com.latchi.iptv.adapter.UserProfilesAdapter
import com.latchi.iptv.model.Channel
import com.latchi.iptv.provider.ChannelsProvider
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.DateText
import com.latchi.iptv.utils.GeminiVoiceController
import android.view.animation.AnimationUtils
import com.latchi.iptv.utils.LastWatchedPrefs
import com.latchi.iptv.utils.SourcePrefs
import com.latchi.iptv.utils.UpdateChecker
import com.latchi.iptv.utils.VoiceCommand
import com.latchi.iptv.utils.VoiceHandler
import com.latchi.iptv.utils.VoiceIndex

class HomeFragment : Fragment() {
    private lateinit var channelsProvider: ChannelsProvider
    private lateinit var cardLive: LinearLayout
    private lateinit var cardMovies: LinearLayout
    private lateinit var cardSeries: LinearLayout
    private lateinit var cardMatches: LinearLayout
    private lateinit var backToHomeButton: LinearLayout
    private lateinit var toolbarSettings: LinearLayout
    private lateinit var toolbarUsers: LinearLayout
    private lateinit var lastWatchedButton: TextView
    private lateinit var whatsappButton: LinearLayout
    private lateinit var liveCount: TextView
    private lateinit var movieCount: TextView
    private lateinit var seriesCount: TextView
    private lateinit var updatedText: TextView
    private lateinit var loggedInText: TextView
    private lateinit var expiryText: TextView
    private lateinit var progressBar: View
    private lateinit var loadingOverlay: View
    private lateinit var usersRecyclerView: RecyclerView
    private lateinit var usersAdapter: UserProfilesAdapter
    private lateinit var drawerLayout: DrawerLayout

    private var cardAIVoice: LinearLayout? = null
    private var voiceOverlay: FrameLayout? = null
    private var voiceHandler: VoiceHandler? = null

    private var saveAfterFetch = false
    private var loadingTimeoutHandler: Handler? = null
    private var adhkarRotatorHandler: Handler? = null
    private var adhkarRotatorRunnable: Runnable? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return try {
            val view = inflater.inflate(R.layout.fragment_home, container, false)
            channelsProvider = ViewModelProvider(this)[ChannelsProvider::class.java]
            
            cardLive = view.findViewById(R.id.cardLive)
            cardMovies = view.findViewById(R.id.cardMovies)
            cardSeries = view.findViewById(R.id.cardSeries)
            cardMatches = view.findViewById(R.id.cardMatches)
            backToHomeButton = view.findViewById(R.id.backToHomeButton)
            toolbarSettings = view.findViewById(R.id.toolbarSettings)
            toolbarUsers = view.findViewById(R.id.toolbarUsers)
            lastWatchedButton = view.findViewById(R.id.lastWatchedButton)
            whatsappButton = view.findViewById(R.id.whatsappButton)
            liveCount = view.findViewById(R.id.liveCount)
            movieCount = view.findViewById(R.id.movieCount)
            seriesCount = view.findViewById(R.id.seriesCount)
            updatedText = view.findViewById(R.id.updatedText)
            loggedInText = view.findViewById(R.id.loggedInText)
            expiryText = view.findViewById(R.id.expiryText)
            progressBar = view.findViewById(R.id.loadingRow)
            loadingOverlay = view.findViewById(R.id.loadingOverlay)
            usersRecyclerView = view.findViewById(R.id.usersRecyclerView)
            drawerLayout = view.findViewById(R.id.drawerLayout)

            cardAIVoice = view.findViewById(R.id.cardAIVoice)
            voiceOverlay = view.findViewById(R.id.voiceOverlay)

            setupDrawer(view)
            setupUsersRecycler()
            setupVoiceHandler()
            setupClicks(view)

            view.findViewById<TextView?>(R.id.tvDateText)?.let { dateView ->
                try {
                    val sdf = java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale("ar"))
                    dateView.text = "📅 " + sdf.format(java.util.Date())
                } catch (_: Exception) { }
            }

            checkUpdateBadge(view)
            view
        } catch (e: Throwable) {
            TextView(requireContext()).apply {
                text = "onCreateView Crash:\n${Log.getStackTraceString(e)}"
                setTextColor(android.graphics.Color.RED)
                setPadding(40, 40, 40, 40)
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            setupObservers()
            loadCachedOrFetch()
            animateUi(view)
        } catch (e: Throwable) {
            Log.e("HomeFragment", "Crash in onViewCreated: ${e.message}")
            AlertDialog.Builder(requireContext())
                .setTitle("HomeFragment Crash")
                .setMessage(Log.getStackTraceString(e))
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun setupDrawer(view: View) {
        view.findViewById<TextView>(R.id.menuButton).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.END)
        }
        view.findViewById<TextView>(R.id.drawerMatches).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), MatchesActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerPrayer).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), PrayerActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerPricing).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), PricingActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerThemeSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), ThemeSettingsActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(requireContext(), SettingsActivity::class.java))
        }
        view.findViewById<TextView>(R.id.drawerAbout).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.app_info_title))
                .setMessage(getString(R.string.app_info_desc))
                .setPositiveButton(getString(R.string.close), null)
                .show()
        }
    }

    private fun setupUsersRecycler() {
        usersAdapter = UserProfilesAdapter(emptyList(), onOpen = { profile ->
            SourcePrefs.setActiveProfile(requireContext(), profile.id)
            requireActivity().recreate()
        }, onDelete = { profile ->
            SourcePrefs.deleteProfile(requireContext(), profile.id)
            refreshUsers()
        })
        usersRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        usersRecyclerView.adapter = usersAdapter
        refreshUsers()
    }

    private fun refreshUsers() {
        val profiles = SourcePrefs.getProfiles(requireContext())
        usersAdapter.update(profiles)
        usersRecyclerView.visibility = if (profiles.size > 1) View.VISIBLE else View.GONE
    }

    private fun animateUi(root: View) {
        try {
            val ctx = root.context
            root.findViewById<View?>(R.id.headerLogo)?.startAnimation(AnimationUtils.loadAnimation(ctx, R.anim.float_updown))
            listOf(R.id.cardLive, R.id.cardMovies, R.id.cardSeries, R.id.cardMatches).forEachIndexed { i, id ->
                root.findViewById<View?>(id)?.let { c ->
                    val anim = AnimationUtils.loadAnimation(ctx, R.anim.card_slide_up).apply { startOffset = (i * 90).toLong() }
                    c.startAnimation(anim)
                }
            }
        } catch (_: Exception) {}
    }

    private fun setupClicks(view: View) {
        cardLive.setOnClickListener { ChannelListActivity.start(requireContext(), "live", getString(R.string.live_tv)) }
        cardMovies.setOnClickListener { ChannelListActivity.start(requireContext(), "movie", getString(R.string.movies)) }
        cardSeries.setOnClickListener { ChannelListActivity.start(requireContext(), "series", getString(R.string.series)) }
        cardMatches.setOnClickListener { startActivity(Intent(requireContext(), MatchesActivity::class.java)) }
        backToHomeButton.setOnClickListener {
            startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
            requireActivity().finish()
        }
        view.findViewById<View?>(R.id.toolbarSettingsTop)?.setOnClickListener { startActivity(Intent(requireContext(), SettingsActivity::class.java)) }
        view.findViewById<View?>(R.id.toolbarUsersTop)?.setOnClickListener { forceUpdate() }
        toolbarSettings.setOnClickListener { startActivity(Intent(requireContext(), SettingsActivity::class.java)) }
        toolbarUsers.setOnClickListener {
            startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true))
            requireActivity().finish()
        }
        cardAIVoice?.setOnClickListener { onAIVoiceClicked() }
        lastWatchedButton.setOnClickListener {
            SourcePrefs.getActiveProfile(requireContext())?.let { active ->
                LastWatchedPrefs.load(requireContext(), active.id)?.let { ch ->
                    PlayerActivity.start(requireContext(), ch)
                } ?: Toast.makeText(requireContext(), getString(R.string.no_last_watched), Toast.LENGTH_SHORT).show()
            }
        }
        whatsappButton.setOnClickListener {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/213798712450"))) } catch (_: Exception) {}
        }
    }

    private fun setupVoiceHandler() {
        val overlay = voiceOverlay ?: return
        voiceHandler = VoiceHandler(requireContext(), overlay, onCommand = { command -> handleVoiceCommand(command) }, onGeminiAction = { action -> handleGeminiAction(action) })
    }

    private fun onAIVoiceClicked() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2026)
            return
        }
        voiceHandler?.startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 2026 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            voiceHandler?.startListening()
        } else {
            Toast.makeText(requireContext(), "صلاحية الميكروفون مطلوبة للبحث الصوتي", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleVoiceCommand(command: VoiceCommand) {
        when (command) {
            is VoiceCommand.Play -> {
                VoiceIndex.findChannel(command.channelName)?.let { PlayerActivity.start(requireContext(), it) } ?: Toast.makeText(requireContext(), "لم أجد قناة: ${command.channelName}", Toast.LENGTH_SHORT).show()
            }
            is VoiceCommand.Navigate -> {
                when (command.screen) {
                    VoiceCommand.Screen.SETTINGS -> startActivity(Intent(requireContext(), SettingsActivity::class.java))
                    VoiceCommand.Screen.MATCHES -> startActivity(Intent(requireContext(), MatchesActivity::class.java))
                    VoiceCommand.Screen.MOVIES -> ChannelListActivity.start(requireContext(), "movie", getString(R.string.movies))
                    VoiceCommand.Screen.SERIES -> ChannelListActivity.start(requireContext(), "series", getString(R.string.series))
                    VoiceCommand.Screen.LIVE -> ChannelListActivity.start(requireContext(), "live", getString(R.string.live_tv))
                    VoiceCommand.Screen.USERS -> { startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true)); requireActivity().finish() }
                    VoiceCommand.Screen.PRICING -> startActivity(Intent(requireContext(), PricingActivity::class.java))
                    VoiceCommand.Screen.PRAYER -> startActivity(Intent(requireContext(), PrayerActivity::class.java))
                    VoiceCommand.Screen.ABOUT -> AlertDialog.Builder(requireContext()).setTitle(getString(R.string.app_info_title)).setMessage(getString(R.string.app_info_desc)).show()
                }
            }
            is VoiceCommand.Search -> ChannelListActivity.start(requireContext(), "live", "نتائج: ${command.query}")
            VoiceCommand.Unknown -> Toast.makeText(requireContext(), "لم أفهم الأمر، حاول مرة أخرى", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleGeminiAction(action: GeminiVoiceController.VoiceAction) {
        if (!action.isConfident()) {
            Toast.makeText(requireContext(), "🤔 أعد المحاولة بوضوح.", Toast.LENGTH_SHORT).show()
            return
        }
        when (action.actionType) {
            "play" -> VoiceIndex.findChannel(action.target)?.let { PlayerActivity.start(requireContext(), it) } ?: Toast.makeText(requireContext(), "🔍 بحث عن: ${action.target}", Toast.LENGTH_SHORT).show()
            "navigate" -> handleVoiceCommand(VoiceCommandParser.parse("روح لـ " + action.screen))
            "search" -> ChannelListActivity.start(requireContext(), "live", "نتائج: ${action.target}")
            else -> Toast.makeText(requireContext(), "ℹ️ ${action.target}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupObservers() {
        channelsProvider.channels.observe(viewLifecycleOwner, Observer { data ->
            try {
                loadingTimeoutHandler?.removeCallbacksAndMessages(null)
                progressBar.visibility = View.GONE
                loadingOverlay.visibility = View.GONE
                stopAdhkarRotator()
                updateCounts(data)
                VoiceIndex.update(data)
                
                val active = SourcePrefs.getActiveProfile(requireContext())
                if (saveAfterFetch && active != null && data.isNotEmpty()) {
                    val profileId = active.id
                    val appContext = requireContext().applicationContext
                    saveAfterFetch = false
                    Thread {
                        ChannelCache.save(appContext, profileId, data)
                        Handler(Looper.getMainLooper()).post {
                            try {
                                updateCacheTime(profileId)
                                Toast.makeText(appContext, getString(R.string.playlist_updated), Toast.LENGTH_SHORT).show()
                            } catch (_: Exception) {}
                        }
                    }.start()
                }
            } catch (e: Throwable) { Log.e("HomeFragment", "Observer Crash: ${e.message}") }
        })
        channelsProvider.error.observe(viewLifecycleOwner, Observer { error ->
            try {
                loadingTimeoutHandler?.removeCallbacksAndMessages(null)
                if (!error.isNullOrBlank()) {
                    progressBar.visibility = View.GONE
                    loadingOverlay.visibility = View.GONE
                    stopAdhkarRotator()
                    Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                }
            } catch (e: Throwable) { Log.e("HomeFragment", "Error Observer Crash: ${e.message}") }
        })
    }

    private fun loadCachedOrFetch() {
        try {
            val active = SourcePrefs.getActiveProfile(requireContext())
            if (active == null) { startActivity(Intent(requireContext(), UserListActivity::class.java).putExtra("show_settings", true)); requireActivity().finish(); return }
            try {
                loggedInText.text = "${getString(R.string.logged_in)}: ${active.name}"
                expiryText.text = "${getString(R.string.expiry)}: ${DateText.shortDate(active.expiresAt)}"
            } catch (_: Throwable) {}
            checkExpiryWarning(active.expiresAt)

            // Extremely snappy multi-threaded Disk cache load
            Thread {
                val cached = ChannelCache.load(requireContext().applicationContext, active.id)
                Handler(Looper.getMainLooper()).post {
                    try {
                        if (cached.isNotEmpty()) {
                            channelsProvider.setLocalChannels(cached)
                            updateCacheTime(active.id)
                            VoiceIndex.update(cached)
                        } else {
                            saveAfterFetch = true
                            progressBar.visibility = View.VISIBLE
                            loadingOverlay.visibility = View.VISIBLE
                            startAdhkarRotator()
                            startLoadingTimeout()
                            channelsProvider.fetchM3UFile(active.m3uUrl)
                        }
                    } catch (_: Exception) {}
                }
            }.start()
        } catch (e: Throwable) {
            Log.e("HomeFragment", "Load Data Crash: ${e.message}")
            AlertDialog.Builder(requireContext()).setTitle("Load Data Crash").setMessage(Log.getStackTraceString(e)).show()
        }
    }

    private fun checkExpiryWarning(expiresAt: String) {
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val expiryDate = sdf.parse(expiresAt) ?: return
            val diffMillis = expiryDate.time - System.currentTimeMillis()
            val diffDays = (diffMillis / (1000 * 60 * 60 * 24)).toInt()
            if (diffDays in 0..3) {
                val msg = if (diffDays == 0) "⏰ اشتراكك ينتهي اليوم! جدّد الآن" else "⏰ اشتراكك ينتهي بعد $diffDays يوم"
                view?.post {
                    Toast.makeText(requireContext(), getString(R.string.expiry_warning, diffDays), Toast.LENGTH_LONG).show()
                    view?.findViewById<TextView?>(R.id.expiryBanner)?.let { b ->
                        b.text = msg; b.visibility = View.VISIBLE; b.setOnClickListener { whatsappButton.performClick() }
                    }
                }
            }
        } catch (_: Exception) {}
    }

    private fun forceUpdate() {
        val active = SourcePrefs.getActiveProfile(requireContext()) ?: return
        saveAfterFetch = true
        progressBar.visibility = View.VISIBLE
        loadingOverlay.visibility = View.VISIBLE
        startAdhkarRotator()
        startLoadingTimeout()
        channelsProvider.fetchM3UFile(active.m3uUrl)
    }

    private fun startLoadingTimeout() {
        loadingTimeoutHandler?.removeCallbacksAndMessages(null)
        loadingTimeoutHandler = Handler(Looper.getMainLooper())
        loadingTimeoutHandler?.postDelayed({
            if (progressBar.visibility == View.VISIBLE) {
                progressBar.visibility = View.GONE
                loadingOverlay.visibility = View.GONE
                stopAdhkarRotator()
                Toast.makeText(requireContext(), "انتهت مهلة التحميل. اضغط 'تحديث'", Toast.LENGTH_LONG).show()
            }
        }, 120000)
    }

    private fun startAdhkarRotator() {
        stopAdhkarRotator()
        val allTexts = resources.getStringArray(R.array.adhkar_items).toList() + resources.getStringArray(R.array.ayat_items).toList()
        val allRefs = resources.getStringArray(R.array.adhkar_references).toList() + resources.getStringArray(R.array.ayat_references).toList()
        loadingOverlay.findViewById<TextView?>(R.id.loadingTitle)?.text = getString(R.string.loading_adhkar_title)
        val tv = loadingOverlay.findViewById<TextView?>(R.id.loadingText)
        val ref = loadingOverlay.findViewById<TextView?>(R.id.loadingRef)
        if (allTexts.isEmpty()) return

        adhkarRotatorHandler = Handler(Looper.getMainLooper())
        adhkarRotatorRunnable = object : Runnable {
            override fun run() {
                val idx = (0 until allTexts.size).random()
                tv?.text = allTexts[idx]; ref?.text = allRefs.getOrNull(idx) ?: ""
                adhkarRotatorHandler?.postDelayed(this, 8000)
            }
        }
        adhkarRotatorHandler?.post(adhkarRotatorRunnable!!)
    }

    private fun stopAdhkarRotator() {
        adhkarRotatorHandler?.removeCallbacksAndMessages(null)
        adhkarRotatorHandler = null; adhkarRotatorRunnable = null
    }

    private fun updateCounts(data: List<Channel>) {
        liveCount.text = "${data.count { it.contentType == "live" }} ${getString(R.string.channels_suffix)}"
        movieCount.text = "${data.count { it.contentType == "movie" }} ${getString(R.string.movies_suffix)}"
        seriesCount.text = "${data.count { it.contentType == "series" }} ${getString(R.string.series_suffix)}"
    }

    private fun updateCacheTime(profileId: String) {
        val time = ChannelCache.updatedAt(requireContext().applicationContext, profileId)
        updatedText.text = "${getString(R.string.last_update)}: " + if (time == 0L) "--" else "✓"
    }

    private fun checkUpdateBadge(view: View) {
        val badge = view.findViewById<TextView?>(R.id.updateBadge) ?: return
        UpdateChecker.checkInBackground(requireActivity(), object : UpdateChecker.OnUpdateListener {
            override fun onUpdateAvailable(versionName: String, notes: String, url: String) {
                badge.visibility = View.VISIBLE
                badge.text = "🔄 ${getString(R.string.update_available)} $versionName"
                badge.setOnClickListener { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        voiceHandler?.destroy()
        voiceHandler = null
        stopAdhkarRotator()
    }
}
