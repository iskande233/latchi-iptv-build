package com.latchi.iptv

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.commit
import com.latchi.iptv.screens.*
import com.latchi.iptv.utils.LocaleHelper
import com.latchi.iptv.utils.MatchNotificationHelper
import com.latchi.iptv.utils.ThemeManager
import com.latchi.iptv.utils.TvUtils

class MainActivity : AppCompatActivity() {

    override fun attachBaseContext(context: Context) {
        super.attachBaseContext(LocaleHelper.wrap(context))
    }

    private var backPressedTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TvUtils.applyOrientation(this)
        ThemeManager.apply(this)
        
        try {
            setContentView(R.layout.activity_main)
            supportFragmentManager.commit(allowStateLoss = true) {
                setReorderingAllowed(true)
                replace(R.id.contentFrame, HomeFragment())
            }
            MatchNotificationHelper.startChecking(this)
        } catch (e: Throwable) {
            Toast.makeText(this, "Crash: ${e.message}", Toast.LENGTH_LONG).show()
        }

        // 🛡️ التعديل الاحترافي الحديث: OnBackPressedDispatcher
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // 0. إذا كانت القائمة الجانبية مفتوحة، نغلقها أولاً
                val drawerLayout = findViewById<DrawerLayout?>(R.id.drawerLayout)
                if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.END)) {
                    drawerLayout.closeDrawer(GravityCompat.END)
                    return
                }

                // 1. إذا كان مشغل القنوات (Player) مفتوحاً أو شغالاً
                if (isPlayerOpen() || isVideoPlaying()) {
                    closeAndStopPlayer()
                    return
                }

                // 2. إذا كان المستخدم في قسم فرعي (Fragments) داخل الرئيسية
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                    return
                }

                // 3. إذا كان المستخدم في الشاشة الرئيسية تماماً، نظهر شاشة تأكيد الخروج الأنيقة
                if (System.currentTimeMillis() - backPressedTime < 2000) {
                    showExitDialog()
                } else {
                    backPressedTime = System.currentTimeMillis()
                    Toast.makeText(this@MainActivity, getString(R.string.press_back_again_exit), Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun isPlayerOpen(): Boolean {
        return false
    }

    private fun isVideoPlaying(): Boolean {
        return false
    }

    private fun closeAndStopPlayer() {
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_exit_title))
            .setMessage(getString(R.string.confirm_exit_desc))
            .setPositiveButton("موافق") { _, _ -> finishAffinity() }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
}
