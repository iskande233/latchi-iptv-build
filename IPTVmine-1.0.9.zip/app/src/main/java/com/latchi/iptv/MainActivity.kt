package com.latchi.iptv

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.commit
import com.latchi.iptv.screens.*
import com.latchi.iptv.utils.ActivationValidator
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.LocaleHelper
import com.latchi.iptv.utils.SourcePrefs
import com.latchi.iptv.utils.TvUtils
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private var progressBar: ProgressBar? = null
    private var percentText: TextView? = null
    private var statusText: TextView? = null
    private var progressHandler: Handler? = null
    private var fakeProgress = 0

    override fun attachBaseContext(context: Context) {
        super.attachBaseContext(LocaleHelper.wrap(context))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TvUtils.applyOrientation(this)
        com.latchi.iptv.utils.ThemeManager.apply(this)
        val profile = SourcePrefs.getActiveProfile(this)
        if (profile == null) {
            goToUsers()
            return
        }
        if (profile.activationCode == "MANUAL") {
            openHomeFragment()
            return
        }
        showCheckingScreen()
        thread {
            try {
                val result = ActivationValidator.validate(this, profile)
                runOnUiThread {
                    if (result.success) {
                        val oldUrl = profile.m3uUrl
                        val newUrl = result.playlistUrl.ifBlank { oldUrl }
                        if (newUrl != oldUrl) ChannelCache.clear(this, profile.id)
                        SourcePrefs.saveActivatedProfile(
                            context = this,
                            code = profile.activationCode,
                            name = result.name,
                            playlistUrl = newUrl,
                            expiresAt = result.expiresAt,
                            maxDevices = result.maxDevices
                        )
                        statusText?.text = getString(R.string.subscription_verified)
                        finishProgressThen { openHomeFragment() }
                    } else {
                        SourcePrefs.deleteProfile(this, profile.id)
                        goExpired(result.message)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    val hasCache = ChannelCache.load(this, profile.id).isNotEmpty()
                    if (hasCache) {
                        Toast.makeText(this, getString(R.string.offline_mode), Toast.LENGTH_SHORT).show()
                        finishProgressThen { openHomeFragment() }
                    } else {
                        showNoConnectionScreen()
                    }
                }
            }
        }
    }

    private fun openHomeFragment() {
        try {
            setContentView(R.layout.activity_main)
            supportFragmentManager.commit(allowStateLoss = true) {
                setReorderingAllowed(true)
                replace(R.id.contentFrame, HomeFragment())
            }
            com.latchi.iptv.utils.MatchNotificationHelper.startChecking(this)
        } catch (e: Throwable) {
            android.widget.Toast.makeText(this, "Crash: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Transition Crash")
                .setMessage(android.util.Log.getStackTraceString(e))
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun showCheckingScreen() {
        setContentView(R.layout.activity_loading)
        progressBar = findViewById(R.id.loadingProgress)
        percentText = findViewById(R.id.loadingPercent)
        statusText = findViewById(R.id.loadingText)
        statusText?.text = getString(R.string.identifying_subscription)
        startFakeProgress()
    }

    private fun startFakeProgress() {
        progressHandler = Handler(Looper.getMainLooper())
        val step = object : Runnable {
            override fun run() {
                if (fakeProgress < 90) {
                    fakeProgress += 2
                    updateProgressUi(fakeProgress)
                    progressHandler?.postDelayed(this, 60)
                }
            }
        }
        progressHandler?.post(step)
    }

    private fun finishProgressThen(action: () -> Unit) {
        progressHandler?.removeCallbacksAndMessages(null)
        val anim = ObjectAnimator.ofInt(progressBar ?: return action(), "progress", fakeProgress, 100)
        anim.duration = 400
        anim.addUpdateListener { percentText?.text = "${it.animatedValue}%" }
        anim.start()
        Handler(Looper.getMainLooper()).postDelayed({ action() }, 450)
    }

    private fun updateProgressUi(value: Int) {
        progressBar?.progress = value
        percentText?.text = "$value%"
    }

    private fun showNoConnectionScreen() {
        progressHandler?.removeCallbacksAndMessages(null)
        setContentView(R.layout.activity_no_connection)
        findViewById<TextView>(R.id.retryButton).setOnClickListener { recreate() }
    }

    private fun goToUsers() {
        val intent = Intent(this, UserListActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun goExpired(message: String) {
        val intent = Intent(this, ExpiredActivity::class.java).apply { putExtra("message", message) }
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        progressHandler?.removeCallbacksAndMessages(null)
    }

    private var backPressedTime = 0L

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Close drawer first if open
        val drawerLayout = findViewById<androidx.drawerlayout.widget.DrawerLayout?>(R.id.drawerLayout)
        if (drawerLayout != null && drawerLayout.isDrawerOpen(androidx.core.view.GravityCompat.END)) {
            drawerLayout.closeDrawer(androidx.core.view.GravityCompat.END)
            return
        }
        if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
        } else {
            // Double back to exit on TV
            if (com.latchi.iptv.utils.TvUtils.isTv(this)) {
                if (System.currentTimeMillis() - backPressedTime < 2000) {
                    super.onBackPressed()
                } else {
                    backPressedTime = System.currentTimeMillis()
                    android.widget.Toast.makeText(this, "اضغط مرة أخرى للخروج", android.widget.Toast.LENGTH_SHORT).show()
                }
            } else {
                super.onBackPressed()
            }
        }
    }
}
