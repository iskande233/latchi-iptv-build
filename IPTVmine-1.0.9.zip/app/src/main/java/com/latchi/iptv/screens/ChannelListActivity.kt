package com.latchi.iptv.screens

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R
import com.latchi.iptv.adapter.CategoryGridAdapter
import com.latchi.iptv.adapter.ChannelsAdapter
import com.latchi.iptv.model.Channel
import com.latchi.iptv.provider.ChannelsProvider
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.FavoritesPrefs
import com.latchi.iptv.utils.SourcePrefs
import com.latchi.iptv.utils.ThemeManager
import com.latchi.iptv.utils.TvUtils

class ChannelListActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(com.latchi.iptv.utils.LocaleHelper.wrap(newBase))
    }

    private lateinit var channelsProvider: ChannelsProvider
    private lateinit var adapter: ChannelsAdapter
    private lateinit var gridAdapter: CategoryGridAdapter

    private lateinit var stickyCatTitle: TextView
    private lateinit var stickyCatSubtitle: TextView
    private lateinit var stickyCategoryBar: LinearLayout

    private lateinit var menuButton: TextView
    private lateinit var searchButton: TextView
    private lateinit var refreshButton: TextView
    private lateinit var searchEditText: EditText
    private lateinit var categorySearchEditText: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private lateinit var catGridRecyclerView: RecyclerView
    private lateinit var categoryOverlayGrid: View
    private lateinit var btnCloseGrid: TextView
    private lateinit var drawerLayout: DrawerLayout

    private var contentType = "live"
    private var screenTitle = "LIVE TV"
    private var currentQuery = ""
    private var categoryQuery = ""
    private var currentCategory = "All"
    private var debounceHandler: Handler? = null
    private var categoryDebounceHandler: Handler? = null
    private var lastChannels: List<Channel> = emptyList()

    companion object {
        private const val EXTRA_TYPE = "extra_type"
        private const val EXTRA_TITLE = "extra_title"
        fun start(context: Context, type: String, title: String) {
            val intent = Intent(context, ChannelListActivity::class.java).apply {
                putExtra(EXTRA_TYPE, type)
                putExtra(EXTRA_TITLE, title)
            }
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        TvUtils.applyOrientation(this)
        ThemeManager.apply(this)
        setContentView(R.layout.activity_channel_list)

        contentType = intent.getStringExtra(EXTRA_TYPE) ?: "live"
        screenTitle = intent.getStringExtra(EXTRA_TITLE) ?: "LIVE TV"

        channelsProvider = ViewModelProvider(this)[ChannelsProvider::class.java]
        
        stickyCatTitle = findViewById(R.id.stickyCatTitle)
        stickyCatSubtitle = findViewById(R.id.stickyCatSubtitle)
        stickyCategoryBar = findViewById(R.id.stickyCategoryBar)

        menuButton = findViewById(R.id.menuButton)
        searchButton = findViewById(R.id.searchButton)
        refreshButton = findViewById(R.id.refreshButton)
        searchEditText = findViewById(R.id.searchEditText)
        categorySearchEditText = findViewById(R.id.categorySearchEditText)
        progressBar = findViewById(R.id.progressBar)
        recyclerView = findViewById(R.id.recyclerView)
        catGridRecyclerView = findViewById(R.id.catGridRecyclerView)
        categoryOverlayGrid = findViewById(R.id.categoryOverlayGrid)
        btnCloseGrid = findViewById(R.id.btnCloseGrid)
        drawerLayout = findViewById(R.id.drawerLayout)

        stickyCatTitle.text = if (screenTitle.contains("LIVE")) "كل القنوات" else screenTitle

        adapter = ChannelsAdapter(
            emptyList(),
            isFavorite = { channel -> activeId()?.let { FavoritesPrefs.isFavorite(this, it, channel.streamUrl) } ?: false },
            onFavoriteClicked = { channel -> activeId()?.let { FavoritesPrefs.toggle(this, it, channel.streamUrl); applyFilter() } },
            onChannelClicked = { channel ->
                when {
                    channel.contentType == "series" || channel.streamUrl.startsWith("series://") -> {
                        val active = SourcePrefs.getActiveProfile(this)
                        if (active != null) {
                            SeriesDetailActivity.start(this, channel, active.m3uUrl)
                        } else {
                            Toast.makeText(this, getString(R.string.series_not_available), Toast.LENGTH_SHORT).show()
                        }
                    }
                    channel.contentType == "movie" -> {
                        MovieDetailActivity.start(this, channel)
                    }
                    else -> {
                        PlayerActivity.start(this, channel)
                    }
                }
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        gridAdapter = CategoryGridAdapter(emptyList()) { item ->
            currentCategory = item.name
            stickyCatTitle.text = if (item.name == "All") "كل القنوات" else if (item.name == "Favorites") "⭐ المفضلة" else item.name
            stickyCatSubtitle.text = "(${item.count} قناة - اضغط للتبديل)"
            closeCategoryGrid()
            applyFilter()
        }
        catGridRecyclerView.layoutManager = GridLayoutManager(this, 3)
        catGridRecyclerView.adapter = gridAdapter

        setupDrawer()

        menuButton.setOnClickListener { finish() }
        refreshButton.visibility = View.GONE
        searchButton.setOnClickListener {
            searchEditText.visibility = if (searchEditText.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchEditText.visibility == View.VISIBLE) searchEditText.requestFocus()
        }

        stickyCategoryBar.setOnClickListener { openCategoryGrid() }
        btnCloseGrid.setOnClickListener { closeCategoryGrid() }

        setupSearch()
        setupCategorySearch()
        setupObservers()
        loadCachedOrFetch()

        intent.getStringExtra("search_query")?.let { q ->
            if (q.isNotBlank()) {
                currentQuery = q
                searchEditText.setText(q)
                searchEditText.visibility = View.VISIBLE
            }
        }
    }

    private fun setupDrawer() {
        findViewById<TextView>(R.id.drawerTodaysMatches)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, MatchesActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerSettings)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerLogout)?.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            val intent = Intent(this, UserListActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun activeId(): String? = SourcePrefs.getActiveProfile(this)?.id

    private fun openCategoryGrid() {
        categoryOverlayGrid.visibility = View.VISIBLE
        buildCategories(lastChannels)
    }

    private fun closeCategoryGrid() {
        categoryOverlayGrid.visibility = View.GONE
    }

    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                debounceHandler?.removeCallbacksAndMessages(null)
                debounceHandler = Handler(Looper.getMainLooper())
                debounceHandler?.postDelayed({ currentQuery = s.toString(); applyFilter() }, 300)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupCategorySearch() {
        categorySearchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                categoryDebounceHandler?.removeCallbacksAndMessages(null)
                categoryDebounceHandler = Handler(Looper.getMainLooper())
                categoryDebounceHandler?.postDelayed({
                    categoryQuery = s.toString()
                    buildCategories(lastChannels)
                }, 250)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupObservers() {
        channelsProvider.channels.observe(this, Observer { data ->
            progressBar.visibility = View.GONE
            lastChannels = data
            buildCategories(data)
            applyFilter()
        })
        channelsProvider.filteredChannels.observe(this, Observer { data -> adapter.updateChannels(data) })
        channelsProvider.error.observe(this, Observer { error ->
            if (!error.isNullOrBlank()) {
                progressBar.visibility = View.GONE
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun loadCachedOrFetch() {
        val active = SourcePrefs.getActiveProfile(this)
        if (active == null) {
            startActivity(Intent(this, UserListActivity::class.java).putExtra("show_settings", true))
            finish()
            return
        }
        Thread {
            val cached = ChannelCache.load(applicationContext, active.id)
            Handler(Looper.getMainLooper()).post {
                if (cached.isNotEmpty()) {
                    channelsProvider.setLocalChannels(cached)
                } else {
                    progressBar.visibility = View.VISIBLE
                    channelsProvider.fetchM3UFile(active.m3uUrl)
                }
            }
        }.start()
    }

    private fun buildCategories(data: List<Channel>) {
        val filtered = data.filter { it.contentType == contentType }
        val cats = mutableListOf("All", "Favorites")
        cats.addAll(filtered.map { it.category }.distinct().sorted())

        val visibleCats = if (categoryQuery.isBlank()) cats else cats.filter { it.contains(categoryQuery, ignoreCase = true) }

        val gridItems = visibleCats.map { cat ->
            val count = when (cat) {
                "All" -> filtered.size
                "Favorites" -> activeId()?.let { FavoritesPrefs.getFavorites(this, it).size } ?: 0
                else -> filtered.count { it.category == cat }
            }
            CategoryGridAdapter.CategoryItem(cat, count)
        }

        gridAdapter.update(gridItems)
    }

    private fun applyFilter() {
        val favs = activeId()?.let { FavoritesPrefs.getFavorites(this, it) } ?: emptySet()
        channelsProvider.filterChannels(currentQuery, contentType, currentCategory, favs)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END)
        } else if (categoryOverlayGrid.visibility == View.VISIBLE) {
            closeCategoryGrid()
        } else {
            super.onBackPressed()
        }
    }
}
