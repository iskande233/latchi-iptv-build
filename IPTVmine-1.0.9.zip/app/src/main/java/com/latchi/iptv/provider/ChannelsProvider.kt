package com.latchi.iptv.provider

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.latchi.iptv.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URI
import java.util.concurrent.TimeUnit

class ChannelsProvider : ViewModel() {
    private val _channels = MutableLiveData<List<Channel>>()
    val channels: LiveData<List<Channel>> get() = _channels

    private val _filteredChannels = MutableLiveData<List<Channel>>()
    val filteredChannels: LiveData<List<Channel>> get() = _filteredChannels

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> get() = _error

    private var fetchJob: Job? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun setLocalChannels(list: List<Channel>) {
        _channels.value = list
        _filteredChannels.value = list
        _error.value = null
    }

    fun fetchM3UFile(sourceUrl: String) {
        fetchJob?.cancel()
        fetchJob = viewModelScope.launch(Dispatchers.IO) {
            var lastError: String? = null
            try {
                // 1️⃣ أولاً: نجرب الـ Xtream API السريع جداً (باستخدام JsonReader المباشر)
                try {
                    val apiChannels = tryXtreamApi(sourceUrl)
                    if (apiChannels.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            _channels.value = apiChannels
                            _filteredChannels.value = apiChannels
                            _error.value = null
                        }
                        return@launch
                    }
                } catch (e: Exception) {
                    lastError = e.localizedMessage
                }

                // 2️⃣ ثانياً: نجرب تحميل الـ M3U المباشر (باستخدام Streaming Line Reader)
                val candidates = buildCandidateUrls(sourceUrl)
                for (url in candidates) {
                    try {
                        val m3uChannels = downloadAndParseM3uStream(url)
                        if (m3uChannels.isNotEmpty()) {
                            withContext(Dispatchers.Main) {
                                _channels.value = m3uChannels
                                _filteredChannels.value = m3uChannels
                                _error.value = null
                            }
                            return@launch
                        } else {
                            lastError = "Playlist is empty"
                        }
                    } catch (e: Exception) {
                        lastError = e.localizedMessage ?: "Connection failed"
                    }
                }

                withContext(Dispatchers.Main) {
                    _error.value = "Failed to fetch playlist: ${lastError ?: "Unknown error"}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _error.value = "Failed to fetch playlist: ${e.localizedMessage ?: "Unknown error"}"
                }
            }
        }
    }

    // ⚡ Streaming Line Reader for massive M3U playlists
    private fun downloadAndParseM3uStream(url: String): List<Channel> {
        val list = mutableListOf<Channel>()
        try {
            val request = Request.Builder()
                .url(cleanUrl(url))
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val stream = response.body?.byteStream() ?: return emptyList()
                
                var name: String? = null
                var logoUrl = ""
                var category = "Other"

                stream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    for (raw in lines) {
                        val line = cleanUrl(raw.trim())
                        when {
                            line.startsWith("#EXTINF") -> {
                                name = extractChannelName(line)
                                logoUrl = extractLogoUrl(line) ?: ""
                                category = normalizeCategory(extractGroupTitle(line).ifBlank { "Other" })
                            }
                            line.isNotBlank() && !line.startsWith("#") && isValidUrl(line) -> {
                                if (!name.isNullOrEmpty()) {
                                    list.add(Channel(name ?: "Unknown", logoUrl, line, category, detectContentType(line, category, name ?: "")))
                                }
                                name = null
                                logoUrl = ""
                                category = "Other"
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ChannelsProvider", "M3U Stream Error: ${e.message}")
        }
        return list
    }

    // ⚡ Streaming JsonReader for massive Xtream API libraries
    private fun tryXtreamApi(sourceUrl: String): List<Channel> {
        val clean = cleanUrl(sourceUrl)
        if (!clean.contains("get.php", ignoreCase = true)) return emptyList()
        val uri = URI(clean)
        val server = "${uri.scheme}://${uri.host}${if (uri.port != -1) ":${uri.port}" else ""}"
        val query = uri.query ?: return emptyList()
        val params = query.split("&").mapNotNull {
            val p = it.split("=", limit = 2)
            if (p.size == 2) p[0] to p[1] else null
        }.toMap()
        val username = params["username"] ?: return emptyList()
        val password = params["password"] ?: return emptyList()

        val list = mutableListOf<Channel>()
        val liveUrl = "$server/player_api.php?username=$username&password=$password&action=get_live_streams"
        val vodUrl = "$server/player_api.php?username=$username&password=$password&action=get_vod_streams"
        val seriesUrl = "$server/player_api.php?username=$username&password=$password&action=get_series"

        val liveCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_live_categories")
        val vodCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_vod_categories")
        val seriesCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_series_categories")

        list.addAll(parseXtreamStreamsUsingJsonReader(liveUrl, "live", liveCatMap, server, username, password))
        list.addAll(parseXtreamStreamsUsingJsonReader(vodUrl, "movie", vodCatMap, server, username, password))
        list.addAll(parseXtreamStreamsUsingJsonReader(seriesUrl, "series", seriesCatMap, server, username, password))

        return list
    }

    private fun parseXtreamStreamsUsingJsonReader(url: String, type: String, catMap: Map<String, String>, server: String, username: String, password: String): List<Channel> {
        val list = mutableListOf<Channel>()
        try {
            val request = Request.Builder()
                .url(cleanUrl(url))
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val stream = response.body?.byteStream() ?: return emptyList()
                
                val reader = android.util.JsonReader(stream.bufferedReader(Charsets.UTF_8))
                reader.use { r ->
                    r.beginArray()
                    while (r.hasNext()) {
                        var id = ""
                        var name = ""
                        var icon = ""
                        var catId = ""
                        var ext = "mp4"

                        r.beginObject()
                        while (r.hasNext()) {
                            val key = r.nextName()
                            when (key) {
                                "stream_id", "series_id" -> {
                                    id = try { r.nextString() } catch (_: Exception) { try { r.nextInt().toString() } catch (_: Exception) { r.skipValue(); "" } }
                                }
                                "name" -> {
                                    name = try { r.nextString() } catch (_: Exception) { r.skipValue(); "Stream" }
                                }
                                "stream_icon", "cover" -> {
                                    icon = try { r.nextString() } catch (_: Exception) { r.skipValue(); "" }
                                }
                                "category_id" -> {
                                    catId = try { r.nextString() } catch (_: Exception) { try { r.nextInt().toString() } catch (_: Exception) { r.skipValue(); "" } }
                                }
                                "container_extension" -> {
                                    ext = try { r.nextString() } catch (_: Exception) { r.skipValue(); "mp4" }
                                }
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()

                        if (id.isNotBlank() && name.isNotBlank()) {
                            val catName = catMap[catId] ?: catId.ifBlank { if (type == "live") "Live" else if (type == "movie") "Movies" else "Series" }
                            val cat = normalizeCategory(catName)
                            val streamUrl = when (type) {
                                "live" -> "$server/live/$username/$password/$id.ts"
                                "movie" -> "$server/movie/$username/$password/$id.$ext"
                                else -> "series://$id"
                            }
                            list.add(Channel(name, icon, streamUrl, cat, type))
                        }
                    }
                    r.endArray()
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("ChannelsProvider", "JsonReader Error for $type: ${e.message}")
        }
        return list
    }

    private fun fetchCategoryMap(url: String): Map<String, String> {
        return try {
            val request = Request.Builder()
                .url(cleanUrl(url))
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyMap()
                val stream = response.body?.byteStream() ?: return emptyMap()
                val reader = android.util.JsonReader(stream.bufferedReader(Charsets.UTF_8))
                val map = HashMap<String, String>()
                reader.use { r ->
                    r.beginArray()
                    while (r.hasNext()) {
                        var id = ""
                        var name = ""
                        r.beginObject()
                        while (r.hasNext()) {
                            when (r.nextName()) {
                                "category_id" -> id = try { r.nextString() } catch (_: Exception) { try { r.nextInt().toString() } catch (_: Exception) { r.skipValue(); "" } }
                                "category_name" -> name = try { r.nextString() } catch (_: Exception) { r.skipValue(); "" }
                                else -> r.skipValue()
                            }
                        }
                        r.endObject()
                        if (id.isNotBlank() && name.isNotBlank()) map[id] = name
                    }
                    r.endArray()
                }
                map
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun buildCandidateUrls(original: String): List<String> {
        val clean = cleanUrl(original)
        val list = linkedSetOf<String>()
        list.add(clean)

        if (clean.contains("get.php", ignoreCase = true)) {
            var plus = clean
            plus = plus.replace("type=m3u_plus", "type=m3u_plus", ignoreCase = true)
            plus = plus.replace("type=m3u", "type=m3u_plus", ignoreCase = true)
            if (!plus.contains("type=", ignoreCase = true)) plus += if (plus.contains("?")) "&type=m3u_plus" else "?type=m3u_plus"
            if (!plus.contains("output=", ignoreCase = true)) plus += "&output=ts"
            list.add(plus)

            val m3u8 = plus.replace("output=ts", "output=m3u8", ignoreCase = true)
            list.add(m3u8)
        }
        return list.toList()
    }

    private fun detectContentType(url: String, group: String, name: String): String {
        val lowerUrl = url.lowercase()
        val lowerGroup = group.lowercase()
        val lowerName = name.lowercase()
        return when {
            lowerUrl.contains("/movie/") || lowerUrl.contains("/vod/") || lowerGroup.contains("movie") || lowerGroup.contains("movies") || lowerGroup.contains("vod") || lowerGroup.contains("film") || lowerGroup.contains("films") || lowerGroup.contains("cinema") || lowerGroup.contains("أفلام") || lowerGroup.contains("افلام") -> "movie"
            lowerUrl.contains("/series/") || lowerGroup.contains("series") || lowerGroup.contains("مسلسلات") || lowerGroup.contains("مسلسل") || lowerName.contains("s01") || lowerName.contains("e01") -> "series"
            else -> "live"
        }
    }

    private fun normalizeCategory(raw: String): String {
        var s = raw.trim()
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (!s.matches(Regex("""\d+"""))) {
            s = s.replace(Regex("""^\d+\s+"""), "").trim()
        }

        return s.ifBlank { "Other" }
    }

    private fun cleanUrl(value: String): String = value.trim().replace("&amp;", "&")
    private fun extractChannelName(line: String): String = line.substringAfterLast(",", "Unknown").replace("[", "").replace("]", "").trim().ifEmpty { "Unknown" }
    private fun extractLogoUrl(line: String): String? = Regex("tvg-logo=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1)
    private fun extractGroupTitle(line: String): String = Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1) ?: ""
    private fun isValidUrl(url: String): Boolean = url.startsWith("http://") || url.startsWith("https://")

    fun filterChannels(query: String, contentType: String, category: String, favoriteUrls: Set<String>) {
        val allChannels = _channels.value ?: emptyList()
        val searching = query.isNotBlank()
        _filteredChannels.value = allChannels.filter { c ->
            val typeOk = contentType == "all" || c.contentType == contentType
            val catOk = when {
                searching && category != "Favorites" -> true
                category == "All" -> true
                category == "Favorites" -> favoriteUrls.contains(c.streamUrl)
                else -> c.category == category
            }
            val searchOk = !searching || c.name.contains(query, true) || c.category.contains(query, true)
            typeOk && catOk && searchOk
        }
    }

    override fun onCleared() {
        super.onCleared()
        fetchJob?.cancel()
    }
}
