package com.latchi.iptv.adapter

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.latchi.iptv.R
import com.latchi.iptv.model.Channel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChannelsAdapter(
    private var channels: List<Channel>,
    private val isFavorite: (Channel) -> Boolean,
    private val onFavoriteClicked: (Channel) -> Unit,
    private val onChannelClicked: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) = holder.bind(channels[position])
    override fun getItemCount(): Int = channels.size

    fun updateChannels(newChannels: List<Channel>) {
        val old = channels
        CoroutineScope(Dispatchers.Default).launch {
            val diffResult = DiffUtil.calculateDiff(ChannelDiffCallback(old, newChannels))
            withContext(Dispatchers.Main) {
                channels = newChannels
                diffResult.dispatchUpdatesTo(this@ChannelsAdapter)
            }
        }
    }

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val logoImageView: ImageView = itemView.findViewById(R.id.logoImageView)
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
        private val typeBadgeTextView: TextView = itemView.findViewById(R.id.typeBadgeTextView)
        private val favoriteButton: ImageView = itemView.findViewById(R.id.favoriteButton)

        fun bind(channel: Channel) {
            nameTextView.text = channel.name
            categoryTextView.text = channel.category

            renderFavorite(isFavorite(channel))

            when (channel.contentType) {
                "movie" -> { typeBadgeTextView.text = "MOVIE"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#7C3AED")) }
                "series" -> { typeBadgeTextView.text = "SERIES"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#DB2777")) }
                else -> { typeBadgeTextView.text = "LIVE"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#16A34A")) }
            }

            Glide.with(itemView.context)
                .load(channel.logoUrl.ifBlank { null })
                .placeholder(R.drawable.ic_tv)
                .error(R.drawable.ic_tv)
                .into(logoImageView)

            favoriteButton.setOnClickListener {
                onFavoriteClicked(channel)
                val nowFav = isFavorite(channel)
                renderFavorite(nowFav)
                animateHeart(favoriteButton, nowFav)
            }

            val isTv = itemView.context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)

            if (isTv) {
                // 📺 نظام التلفاز: يتم تفعيل الـ Focus
                itemView.isFocusable = true
                itemView.isFocusableInTouchMode = false
                itemView.isClickable = true
                itemView.setOnClickListener { onChannelClicked(channel) }
                itemView.setOnLongClickListener { performFavoriteToggle(channel); true }
            } else {
                // 📱 نظام الهاتف: استجابة فورية ونظيفة من ضغطة واحدة (Single click) بدون أي بقايا Focus
                itemView.isFocusable = false
                itemView.isFocusableInTouchMode = false
                itemView.isClickable = true
                itemView.setOnClickListener { onChannelClicked(channel) }
                itemView.setOnLongClickListener { performFavoriteToggle(channel); true }
            }
        }

        private fun performFavoriteToggle(channel: Channel) {
            onFavoriteClicked(channel)
            val nowFav = isFavorite(channel)
            renderFavorite(nowFav)
            animateHeart(favoriteButton, nowFav)
            val msg = if (nowFav) itemView.context.getString(R.string.added_to_favorites)
                      else itemView.context.getString(R.string.removed_from_favorites)
            Toast.makeText(itemView.context, msg, Toast.LENGTH_SHORT).show()
        }

        private fun renderFavorite(fav: Boolean) {
            favoriteButton.setImageResource(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline)
        }

        private fun animateHeart(view: View, added: Boolean) {
            val peak = if (added) 1.6f else 1.3f
            view.animate().cancel()
            view.scaleX = 0.7f; view.scaleY = 0.7f
            view.animate().scaleX(peak).scaleY(peak).setDuration(140).setInterpolator(OvershootInterpolator(3f)).withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }.start()
        }
    }

    private class ChannelDiffCallback(private val oldList: List<Channel>, private val newList: List<Channel>) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size
        override fun getNewListSize(): Int = newList.size
        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].streamUrl == newList[newItemPosition].streamUrl
        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]
    }
}
