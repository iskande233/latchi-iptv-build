package com.latchi.iptv.provider

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.latchi.iptv.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URI
import java.util.concurrent.TimeUnit

class ChannelsProvider : ViewModel() {
    private val _channels = MutableLiveData<List<Channel>>()
    val channels: LiveData<List<Channel>> get() = _channels

    private val _filteredChannels = MutableLiveData<List<Channel>>()
    val filteredChannels: LiveData<List<Channel>> get() = _filteredChannels

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> get() = _error

    private var fetchJob: Job? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun setLocalChannels(list: List<Channel>) {
        _channels.value = list
        _filteredChannels.value = list
        _error.value = null
    }

    fun fetchM3UFile(sourceUrl: String) {
        fetchJob?.cancel()
        fetchJob = viewModelScope.launch(Dispatchers.IO) {
            var lastError: String? = null
            try {
                val candidates = buildCandidateUrls(sourceUrl)
                for (url in candidates) {
                    try {
                        val body = downloadText(url)
                        val parsed = parseM3UFile(body)
                        if (parsed.isNotEmpty()) {
                            // Also try Xtream API to get movies/series
                            val combined = parsed.toMutableList()
                            try {
                                val xtreamExtra = tryXtreamApi(sourceUrl)
                                val existingUrls = parsed.map { it.streamUrl }.toSet()
                                combined.addAll(xtreamExtra.filter { it.streamUrl !in existingUrls })
                            } catch (_: Exception) {}
                            withContext(Dispatchers.Main) {
                                _channels.value = combined
                                _filteredChannels.value = combined
                                _error.value = null
                            }
                            return@launch
                        } else {
                            lastError = "Playlist is empty"
                        }
                    } catch (e: Exception) {
                        lastError = e.localizedMessage ?: "Connection failed"
                    }
                }

                // Last fallback: try Xtream API for get.php links
                try {
                    val apiChannels = tryXtreamApi(sourceUrl)
                    if (apiChannels.isNotEmpty()) {
                        withContext(Dispatchers.Main) {
                            _channels.value = apiChannels
                            _filteredChannels.value = apiChannels
                            _error.value = null
                        }
                        return@launch
                    }
                } catch (e: Exception) {
                    lastError = e.localizedMessage ?: lastError
                }

                withContext(Dispatchers.Main) {
                    _error.value = "Failed to fetch playlist: ${lastError ?: "Unknown error"}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _error.value = "Failed to fetch playlist: ${e.localizedMessage ?: "Unknown error"}"
                }
            }
        }
    }

    private fun downloadText(url: String): String {
        val request = Request.Builder()
            .url(cleanUrl(url))
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 IPTVPlayer/1.0")
            .header("Accept", "*/*")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            return response.body?.string() ?: throw Exception("Empty response")
        }
    }

    private fun buildCandidateUrls(original: String): List<String> {
        val clean = cleanUrl(original)
        val list = linkedSetOf<String>()
        list.add(clean)

        if (clean.contains("get.php", ignoreCase = true)) {
            var plus = clean
            plus = plus.replace("type=m3u_plus", "type=m3u_plus", ignoreCase = true)
            plus = plus.replace("type=m3u", "type=m3u_plus", ignoreCase = true)
            if (!plus.contains("type=", ignoreCase = true)) plus += if (plus.contains("?")) "&type=m3u_plus" else "?type=m3u_plus"
            if (!plus.contains("output=", ignoreCase = true)) plus += "&output=ts"
            list.add(plus)

            val m3u8 = plus.replace("output=ts", "output=m3u8", ignoreCase = true)
            list.add(m3u8)
        }
        return list.toList()
    }

    private fun parseM3UFile(fileText: String): List<Channel> {
        val lines = fileText.lines()
        val channelsList = mutableListOf<Channel>()
        var name: String? = null
        var logoUrl = ""
        var category = "Other"
        for (raw in lines) {
            val line = cleanUrl(raw.trim())
            when {
                line.startsWith("#EXTINF") -> {
                    name = extractChannelName(line)
                    logoUrl = extractLogoUrl(line) ?: ""
                    category = normalizeCategory(extractGroupTitle(line).ifBlank { "Other" })
                }
                line.isNotBlank() && !line.startsWith("#") && isValidUrl(line) -> {
                    if (!name.isNullOrEmpty()) {
                        channelsList.add(Channel(name ?: "Unknown", logoUrl, line, category, detectContentType(line, category, name ?: "")))
                    }
                    name = null
                    logoUrl = ""
                    category = "Other"
                }
            }
        }
        return channelsList
    }

    private fun tryXtreamApi(sourceUrl: String): List<Channel> {
        val clean = cleanUrl(sourceUrl)
        if (!clean.contains("get.php", ignoreCase = true)) return emptyList()
        val uri = URI(clean)
        val server = "${uri.scheme}://${uri.host}${if (uri.port != -1) ":${uri.port}" else ""}"
        val query = uri.query ?: return emptyList()
        val params = query.split("&").mapNotNull {
            val p = it.split("=", limit = 2)
            if (p.size == 2) p[0] to p[1] else null
        }.toMap()
        val username = params["username"] ?: return emptyList()
        val password = params["password"] ?: return emptyList()

        val list = mutableListOf<Channel>()
        val liveUrl = "$server/player_api.php?username=$username&password=$password&action=get_live_streams"
        val vodUrl = "$server/player_api.php?username=$username&password=$password&action=get_vod_streams"
        val seriesUrl = "$server/player_api.php?username=$username&password=$password&action=get_series"

        // Fetch category maps (category_id -> real category_name)
        val liveCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_live_categories")
        val vodCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_vod_categories")
        val seriesCatMap = fetchCategoryMap("$server/player_api.php?username=$username&password=$password&action=get_series_categories")

        try {
            val liveArr = JSONArray(downloadText(liveUrl))
            for (i in 0 until liveArr.length()) {
                val o = liveArr.getJSONObject(i)
                val id = o.optString("stream_id")
                val title = o.optString("name", "Live")
                val logo = o.optString("stream_icon", "")
                val catId = o.optString("category_id", "")
                val catName = liveCatMap[catId] ?: catId.ifBlank { "Live" }
                val cat = normalizeCategory(catName)
                if (id.isNotBlank()) list.add(Channel(title, logo, "$server/live/$username/$password/$id.ts", cat, "live"))
            }
        } catch (_: Exception) { }

        try {
            val vodArr = JSONArray(downloadText(vodUrl))
            for (i in 0 until vodArr.length()) {
                val o = vodArr.getJSONObject(i)
                val id = o.optString("stream_id")
                val title = o.optString("name", "Movie")
                val logo = o.optString("stream_icon", "")
                val catId = o.optString("category_id", "")
                val catName = vodCatMap[catId] ?: catId.ifBlank { "Movies" }
                val cat = normalizeCategory(catName)
                val ext = o.optString("container_extension", "mp4").ifBlank { "mp4" }
                if (id.isNotBlank()) list.add(Channel(title, logo, "$server/movie/$username/$password/$id.$ext", cat, "movie"))
            }
        } catch (_: Exception) { }

        // Series: store a marker url (series://<id>); episodes are fetched on demand
        try {
            val seriesArr = JSONArray(downloadText(seriesUrl))
            for (i in 0 until seriesArr.length()) {
                val o = seriesArr.getJSONObject(i)
                val id = o.optString("series_id")
                val title = o.optString("name", "Series")
                val logo = o.optString("cover", "")
                val catId = o.optString("category_id", "")
                val catName = seriesCatMap[catId] ?: catId.ifBlank { "Series" }
                val cat = normalizeCategory(catName)
                if (id.isNotBlank()) list.add(Channel(title, logo, "series://$id", cat, "series"))
            }
        } catch (_: Exception) { }

        return list
    }

    // Downloads a categories endpoint and returns a map of category_id -> category_name
    private fun fetchCategoryMap(url: String): Map<String, String> {
        return try {
            val arr = JSONArray(downloadText(url))
            val map = HashMap<String, String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("category_id", "")
                val name = o.optString("category_name", "")
                if (id.isNotBlank() && name.isNotBlank()) map[id] = name
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun detectContentType(url: String, group: String, name: String): String {
        val lowerUrl = url.lowercase()
        val lowerGroup = group.lowercase()
        val lowerName = name.lowercase()
        return when {
            lowerUrl.contains("/movie/") || lowerUrl.contains("/vod/") || lowerGroup.contains("movie") || lowerGroup.contains("movies") || lowerGroup.contains("vod") || lowerGroup.contains("film") || lowerGroup.contains("films") || lowerGroup.contains("cinema") || lowerGroup.contains("أفلام") || lowerGroup.contains("افلام") -> "movie"
            lowerUrl.contains("/series/") || lowerGroup.contains("series") || lowerGroup.contains("مسلسلات") || lowerGroup.contains("مسلسل") || lowerName.contains("s01") || lowerName.contains("e01") -> "series"
            else -> "live"
        }
    }

    // Light cleanup only: keep the FULL original category name (like professional apps),
    // just tidy spacing and strip a leading numeric id if the source sent one.
    private fun normalizeCategory(raw: String): String {
        var s = raw.trim()
            .replace(Regex("""\s+"""), " ")
            .trim()

        // If the value is ONLY a number (e.g. "104"), keep it as-is (no name available)
        // Otherwise remove a leading "104 " numeric prefix that some panels prepend.
        if (!s.matches(Regex("""\d+"""))) {
            s = s.replace(Regex("""^\d+\s+"""), "").trim()
        }

        return s.ifBlank { "Other" }
    }

    private fun cleanUrl(value: String): String = value.trim().replace("&amp;", "&")
    private fun extractChannelName(line: String): String = line.substringAfterLast(",", "Unknown").replace("[", "").replace("]", "").trim().ifEmpty { "Unknown" }
    private fun extractLogoUrl(line: String): String? = Regex("tvg-logo=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1)
    private fun extractGroupTitle(line: String): String = Regex("group-title=\"([^\"]*)\"").find(line)?.groupValues?.getOrNull(1) ?: ""
    private fun isValidUrl(url: String): Boolean = url.startsWith("http://") || url.startsWith("https://")

    fun filterChannels(query: String, contentType: String, category: String, favoriteUrls: Set<String>) {
        val allChannels = _channels.value ?: emptyList()
        val searching = query.isNotBlank()
        _filteredChannels.value = allChannels.filter { c ->
            val typeOk = contentType == "all" || c.contentType == contentType
            // When the user is searching, ignore the selected category so results come
            // from the WHOLE content type (global search), except keep Favorites scoping.
            val catOk = when {
                searching && category != "Favorites" -> true
                category == "All" -> true
                category == "Favorites" -> favoriteUrls.contains(c.streamUrl)
                else -> c.category == category
            }
            val searchOk = !searching || c.name.contains(query, true) || c.category.contains(query, true)
            typeOk && catOk && searchOk
        }
    }

    override fun onCleared() {
        super.onCleared()
        fetchJob?.cancel()
    }
}
