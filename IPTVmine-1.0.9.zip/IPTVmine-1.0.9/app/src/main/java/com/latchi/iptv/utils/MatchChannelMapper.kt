package com.latchi.iptv.utils

import com.latchi.iptv.model.Channel

/**
 * Maps a channel name (from Gemini or known list) to an actual Channel object
 * from the loaded IPTV playlist. Supports fuzzy matching within sports groups only.
 */
object MatchChannelMapper {

    private val knownMappings = mapOf(
        "bein sports 1" to listOf("bein sports 1", "bein 1", "bein sport 1", "bein sport hd1", "beinsport 1", "bein sports 1 hd", "bein 1 hd", "bein sport 1 hd", "bein sport 1 fhd", "bein 1 fhd"),
        "bein sports 2" to listOf("bein sports 2", "bein 2", "bein sport 2", "beinsport 2", "bein sports 2 hd", "bein 2 hd", "bein sport 2 hd", "bein sport 2 fhd", "bein 2 fhd"),
        "bein sports 3" to listOf("bein sports 3", "bein 3", "bein sport 3", "beinsport 3", "bein sports 3 hd", "bein 3 hd", "bein sport 3 hd", "bein sport 3 fhd", "bein 3 fhd"),
        "bein sports 4" to listOf("bein sports 4", "bein 4", "bein sport 4", "beinsport 4", "bein sports 4 hd", "bein 4 hd", "bein sport 4 hd", "bein sport 4 fhd", "bein 4 fhd"),
        "bein sports 5" to listOf("bein sports 5", "bein 5", "bein sport 5", "beinsport 5", "bein sports 5 hd", "bein 5 hd", "bein sport 5 hd", "bein sport 5 fhd", "bein 5 fhd"),
        "bein sports 6" to listOf("bein sports 6", "bein 6", "bein sport 6", "beinsport 6", "bein sports 6 hd", "bein 6 hd", "bein sport 6 hd", "bein sport 6 fhd", "bein 6 fhd"),
        "bein sports 7" to listOf("bein sports 7", "bein 7", "bein sport 7", "beinsport 7", "bein sports 7 hd", "bein 7 hd", "bein sport 7 hd", "bein sport 7 fhd", "bein 7 fhd"),
        "bein sports 8" to listOf("bein sports 8", "bein 8", "bein sport 8", "beinsport 8", "bein sports 8 hd", "bein 8 hd", "bein sport 8 hd", "bein sport 8 fhd", "bein 8 fhd"),
        "bein sports 9" to listOf("bein sports 9", "bein 9", "bein sport 9", "beinsport 9", "bein sports 9 hd", "bein 9 hd", "bein sport 9 hd", "bein sport 9 fhd", "bein 9 fhd"),
        "bein sports 10" to listOf("bein sports 10", "bein 10", "bein sport 10", "beinsport 10", "bein sports 10 hd", "bein 10 hd", "bein sport 10 hd", "bein sport 10 fhd", "bein 10 fhd"),
        "bein sports 11" to listOf("bein sports 11", "bein 11", "bein sport 11", "beinsport 11", "bein sports 11 hd", "bein 11 hd", "bein sport 11 hd", "bein sport 11 fhd", "bein 11 fhd"),
        "bein sports 12" to listOf("bein sports 12", "bein 12", "bein sport 12", "beinsport 12", "bein sports 12 hd", "bein 12 hd", "bein sport 12 hd", "bein sport 12 fhd", "bein 12 fhd"),
        "bein sports premium 1" to listOf("bein premium 1", "bein sports premium 1", "bein premium1", "bein sports premium 1 hd", "bein premium 1 hd", "bein premium 1 fhd"),
        "bein sports premium 2" to listOf("bein premium 2", "bein sports premium 2", "bein premium2", "bein sports premium 2 hd", "bein premium 2 hd", "bein premium 2 fhd"),
        "bein sports premium 3" to listOf("bein premium 3", "bein sports premium 3", "bein premium3", "bein sports premium 3 hd", "bein premium 3 hd", "bein premium 3 fhd"),
        "ssc 1" to listOf("ssc 1", "ssc1", "ssc sports 1", "ssc 1 hd", "ssc1 hd", "ssc 1 fhd"),
        "ssc 2" to listOf("ssc 2", "ssc2", "ssc sports 2", "ssc 2 hd", "ssc2 hd", "ssc 2 fhd"),
        "ssc 3" to listOf("ssc 3", "ssc3", "ssc sports 3", "ssc 3 hd", "ssc3 hd", "ssc 3 fhd"),
        "ssc 4" to listOf("ssc 4", "ssc4", "ssc sports 4", "ssc 4 hd", "ssc4 hd", "ssc 4 fhd"),
        "ssc 5" to listOf("ssc 5", "ssc5", "ssc sports 5", "ssc 5 hd", "ssc5 hd", "ssc 5 fhd"),
        "on time sports" to listOf("on time sports", "ontime sports", "on time sport", "on time"),
        "on time sports 1" to listOf("on time sports 1", "ontime sports 1", "on time 1", "on time 1 hd", "on time 1 fhd"),
        "on time sports 2" to listOf("on time sports 2", "ontime sports 2", "on time 2", "on time 2 hd", "on time 2 fhd"),
        "abu dhabi sports" to listOf("abu dhabi sports", "ad sports", "abudhabi sports", "abu dhabi sports hd", "ad sports hd"),
        "abu dhabi sports 1" to listOf("abu dhabi sports 1", "ad sports 1", "abudhabi sports 1", "abu dhabi sports 1 hd", "ad sports 1 hd", "abu dhabi sports 1 fhd"),
        "abu dhabi sports 2" to listOf("abu dhabi sports 2", "ad sports 2", "abudhabi sports 2", "abu dhabi sports 2 hd", "ad sports 2 hd", "abu dhabi sports 2 fhd"),
        "dubai sports" to listOf("dubai sports", "dubai sport", "dubai sports hd", "dubai sport hd"),
        "dubai sports 1" to listOf("dubai sports 1", "dubai sport 1", "dubai sports 1 hd", "dubai sport 1 hd", "dubai sports 1 fhd"),
        "dubai sports 2" to listOf("dubai sports 2", "dubai sport 2", "dubai sports 2 hd", "dubai sport 2 hd", "dubai sports 2 fhd"),
        "yas sports" to listOf("yas sports", "yas sport", "yas sports hd", "yas sport hd"),
        "kass" to listOf("kass", "kass sport", "kass sports", "kass hd", "kass sport hd"),
        "kass 1" to listOf("kass 1", "kass sport 1", "kass 1 hd", "kass sport 1 hd", "kass 1 fhd"),
        "kass 2" to listOf("kass 2", "kass sport 2", "kass 2 hd", "kass sport 2 hd", "kass 2 fhd"),
        "kass 3" to listOf("kass 3", "kass sport 3", "kass 3 hd", "kass sport 3 hd", "kass 3 fhd"),
        "alkass" to listOf("alkass", "alkass 1", "alkass 2", "alkass 3", "alkass hd", "alkass 1 hd", "alkass 2 hd", "alkass 3 hd"),
        "alkass 1" to listOf("alkass 1", "alkass one", "al kass 1", "alkass 1 hd", "alkass 1 fhd"),
        "alkass 2" to listOf("alkass 2", "alkass two", "al kass 2", "alkass 2 hd", "alkass 2 fhd"),
        "alkass 3" to listOf("alkass 3", "alkass three", "al kass 3", "alkass 3 hd", "alkass 3 fhd"),
        "alkass 4" to listOf("alkass 4", "alkass four", "al kass 4", "alkass 4 hd", "alkass 4 fhd"),
        "alkass 5" to listOf("alkass 5", "alkass five", "al kass 5", "alkass 5 hd", "alkass 5 fhd"),
        "mbc pro sport" to listOf("mbc pro sport", "mbc pro sports", "mbc prosports", "mbc pro sport hd"),
        "mbc pro sport 1" to listOf("mbc pro sport 1", "mbc pro sports 1", "mbc prosports 1", "mbc pro sport 1 hd", "mbc pro sport 1 fhd"),
        "mbc pro sport 2" to listOf("mbc pro sport 2", "mbc pro sports 2", "mbc prosports 2", "mbc pro sport 2 hd", "mbc pro sport 2 fhd"),
        "mbc pro sport 3" to listOf("mbc pro sport 3", "mbc pro sports 3", "mbc prosports 3", "mbc pro sport 3 hd", "mbc pro sport 3 fhd"),
        "sports tv" to listOf("sports tv", "sport tv", "sports tv hd", "sport tv hd"),
        "sport tv" to listOf("sport tv", "sport tv 1", "sport tv 2", "sport tv hd", "sport tv 1 hd", "sport tv 2 hd"),
        "sport tv 1" to listOf("sport tv 1", "sporttv1", "sport tv 1 hd", "sport tv 1 fhd"),
        "sport tv 2" to listOf("sport tv 2", "sporttv2", "sport tv 2 hd", "sport tv 2 fhd"),
        "sport tv 3" to listOf("sport tv 3", "sporttv3", "sport tv 3 hd", "sport tv 3 fhd"),
        "sport tv 4" to listOf("sport tv 4", "sporttv4", "sport tv 4 hd", "sport tv 4 fhd"),
        "sport tv 5" to listOf("sport tv 5", "sporttv5", "sport tv 5 hd", "sport tv 5 fhd"),
        "eleven sports" to listOf("eleven sports", "eleven sport", "eleven sports hd", "eleven sport hd"),
        "eleven sports 1" to listOf("eleven sports 1", "eleven sport 1", "eleven 1", "eleven sports 1 hd", "eleven 1 hd", "eleven 1 fhd"),
        "eleven sports 2" to listOf("eleven sports 2", "eleven sport 2", "eleven 2", "eleven sports 2 hd", "eleven 2 hd", "eleven 2 fhd"),
        "bt sport" to listOf("bt sport", "bt sports", "bt sport 1", "bt sport 2", "bt sport 3", "bt sport hd", "bt sports hd"),
        "bt sport 1" to listOf("bt sport 1", "btsport 1", "bt sports 1", "bt sport 1 hd", "bt sport 1 fhd"),
        "bt sport 2" to listOf("bt sport 2", "btsport 2", "bt sports 2", "bt sport 2 hd", "bt sport 2 fhd"),
        "bt sport 3" to listOf("bt sport 3", "btsport 3", "bt sports 3", "bt sport 3 hd", "bt sport 3 fhd"),
        "sky sport" to listOf("sky sport", "sky sports", "sky sport 1", "sky sport hd", "sky sports hd"),
        "sky sport 1" to listOf("sky sport 1", "skysport 1", "sky sports 1", "sky sport 1 hd", "sky sport 1 fhd"),
        "sky sport 2" to listOf("sky sport 2", "skysport 2", "sky sports 2", "sky sport 2 hd", "sky sport 2 fhd"),
        "sky sport 3" to listOf("sky sport 3", "skysport 3", "sky sports 3", "sky sport 3 hd", "sky sport 3 fhd"),
        "espn" to listOf("espn", "espn usa", "espn 1", "espn hd", "espn 1 hd"),
        "fox sports" to listOf("fox sports", "fox sport", "fox sports hd", "fox sport hd"),
        "fox sports 1" to listOf("fox sports 1", "fox sport 1", "foxsports 1", "fs1", "fox sports 1 hd", "fox sport 1 hd", "fox sports 1 fhd"),
        "fox sports 2" to listOf("fox sports 2", "fox sport 2", "foxsports 2", "fs2", "fox sports 2 hd", "fox sport 2 hd", "fox sports 2 fhd"),
        "tyc sports" to listOf("tyc sports", "tyc sport", "tyc sports hd", "tyc sport hd"),
        "dazn" to listOf("dazn", "dazn 1", "dazn 2", "dazn 3", "dazn 4", "dazn hd", "dazn 1 hd", "dazn 1 fhd"),
        "dazn 1" to listOf("dazn 1", "dazn 1 hd", "dazn 1 fhd"),
        "dazn 2" to listOf("dazn 2", "dazn 2 hd", "dazn 2 fhd"),
        "dazn 3" to listOf("dazn 3", "dazn 3 hd", "dazn 3 fhd"),
        "dazn 4" to listOf("dazn 4", "dazn 4 hd", "dazn 4 fhd"),
        "tnt sports" to listOf("tnt sports", "tnt sport", "tnt sports hd", "tnt sport hd"),
        "tnt sports 1" to listOf("tnt sports 1", "tnt sport 1", "tnt sports 1 hd", "tnt sport 1 hd", "tnt sports 1 fhd"),
        "tnt sports 2" to listOf("tnt sports 2", "tnt sport 2", "tnt sports 2 hd", "tnt sport 2 hd", "tnt sports 2 fhd"),
        "tnt sports 3" to listOf("tnt sports 3", "tnt sport 3", "tnt sports 3 hd", "tnt sport 3 hd", "tnt sports 3 fhd"),
        "tnt sports 4" to listOf("tnt sports 4", "tnt sport 4", "tnt sports 4 hd", "tnt sport 4 hd", "tnt sports 4 fhd"),
        "arena sport" to listOf("arena sport", "arena sports", "arena sport hd", "arena sports hd"),
        "arena sport 1" to listOf("arena sport 1", "arena sports 1", "arena 1", "arena sport 1 hd", "arena 1 hd", "arena sport 1 fhd"),
        "arena sport 2" to listOf("arena sport 2", "arena sports 2", "arena 2", "arena sport 2 hd", "arena 2 hd", "arena sport 2 fhd"),
        "arena sport 3" to listOf("arena sport 3", "arena sports 3", "arena 3", "arena sport 3 hd", "arena 3 hd", "arena sport 3 fhd"),
        "arena sport 4" to listOf("arena sport 4", "arena sports 4", "arena 4", "arena sport 4 hd", "arena 4 hd", "arena sport 4 fhd"),
        "prima sport" to listOf("prima sport", "prima sports", "prima sport hd", "prima sports hd"),
        "prima sport 1" to listOf("prima sport 1", "prima sports 1", "prima 1", "prima sport 1 hd", "prima 1 hd", "prima sport 1 fhd"),
        "prima sport 2" to listOf("prima sport 2", "prima sports 2", "prima 2", "prima sport 2 hd", "prima 2 hd", "prima sport 2 fhd"),
        "prima sport 3" to listOf("prima sport 3", "prima sports 3", "prima 3", "prima sport 3 hd", "prima 3 hd", "prima sport 3 fhd"),
        "prima sport 4" to listOf("prima sport 4", "prima sports 4", "prima 4", "prima sport 4 hd", "prima 4 hd", "prima sport 4 fhd"),
        "polsat sport" to listOf("polsat sport", "polsat sports", "polsat sport hd", "polsat sports hd"),
        "polsat sport 1" to listOf("polsat sport 1", "polsat sports 1", "polsat 1", "polsat sport 1 hd", "polsat 1 hd", "polsat sport 1 fhd"),
        "polsat sport 2" to listOf("polsat sport 2", "polsat sports 2", "polsat 2", "polsat sport 2 hd", "polsat 2 hd", "polsat sport 2 fhd"),
        "polsat sport 3" to listOf("polsat sport 3", "polsat sports 3", "polsat 3", "polsat sport 3 hd", "polsat 3 hd", "polsat sport 3 fhd"),
        "canal+ sport" to listOf("canal+ sport", "canal+ sports", "canal sport", "canal+ sport hd", "canal sport hd"),
        "canal+ sport 1" to listOf("canal+ sport 1", "canal+ sports 1", "canal sport 1", "canal+ sport 1 hd", "canal sport 1 hd", "canal+ sport 1 fhd"),
        "canal+ sport 2" to listOf("canal+ sport 2", "canal+ sports 2", "canal sport 2", "canal+ sport 2 hd", "canal sport 2 hd", "canal+ sport 2 fhd"),
        "canal+ sport 3" to listOf("canal+ sport 3", "canal+ sports 3", "canal sport 3", "canal+ sport 3 hd", "canal sport 3 hd", "canal+ sport 3 fhd"),
        "canal+ sport 4" to listOf("canal+ sport 4", "canal+ sports 4", "canal sport 4", "canal+ sport 4 hd", "canal sport 4 hd", "canal+ sport 4 fhd"),
        "canal+ sport 5" to listOf("canal+ sport 5", "canal+ sports 5", "canal sport 5", "canal+ sport 5 hd", "canal sport 5 hd", "canal+ sport 5 fhd"),
        "eurosport" to listOf("eurosport", "eurosport 1", "eurosport 2", "eurosport hd", "eurosport 1 hd", "eurosport 1 fhd"),
        "eurosport 1" to listOf("eurosport 1", "eurosport one", "eurosport 1 hd", "eurosport 1 fhd"),
        "eurosport 2" to listOf("eurosport 2", "eurosport two", "eurosport 2 hd", "eurosport 2 fhd"),
        "la liga tv" to listOf("la liga tv", "laliga tv", "la liga", "la liga tv hd", "laliga tv hd"),
        "movistar la liga" to listOf("movistar la liga", "movistar laliga", "movistar la liga hd"),
        "bein la liga" to listOf("bein la liga", "bein laliga", "bein la liga hd"),
        "premier league tv" to listOf("premier league tv", "premier league", "premier league tv hd"),
        "sky premier league" to listOf("sky premier league", "sky pl", "premier league hd", "sky premier league hd"),
        "super sport" to listOf("super sport", "supersport", "super sport 1", "supersport 1", "super sport hd", "supersport hd"),
        "super sport 1" to listOf("super sport 1", "supersport 1", "super sport1", "supersport1", "super sport 1 hd", "supersport 1 hd", "super sport 1 fhd"),
        "super sport 2" to listOf("super sport 2", "supersport 2", "super sport2", "supersport2", "super sport 2 hd", "supersport 2 hd", "super sport 2 fhd"),
        "super sport 3" to listOf("super sport 3", "supersport 3", "super sport3", "supersport3", "super sport 3 hd", "supersport 3 hd", "super sport 3 fhd"),
        "super sport 4" to listOf("super sport 4", "supersport 4", "super sport4", "supersport4", "super sport 4 hd", "supersport 4 hd", "super sport 4 fhd"),
        "super sport 5" to listOf("super sport 5", "supersport 5", "super sport5", "supersport5", "super sport 5 hd", "supersport 5 hd", "super sport 5 fhd"),
        "super sport 6" to listOf("super sport 6", "supersport 6", "super sport6", "supersport6", "super sport 6 hd", "supersport 6 hd", "super sport 6 fhd"),
        "super sport 7" to listOf("super sport 7", "supersport 7", "super sport7", "supersport7", "super sport 7 hd", "supersport 7 hd", "super sport 7 fhd"),
        "super sport 8" to listOf("super sport 8", "supersport 8", "super sport8", "supersport8", "super sport 8 hd", "supersport 8 hd", "super sport 8 fhd"),
        "super sport 9" to listOf("super sport 9", "supersport 9", "super sport9", "supersport9", "super sport 9 hd", "supersport 9 hd", "super sport 9 fhd"),
        "super sport 10" to listOf("super sport 10", "supersport 10", "super sport10", "supersport10", "super sport 10 hd", "supersport 10 hd", "super sport 10 fhd"),
        "super sport 11" to listOf("super sport 11", "supersport 11", "super sport11", "supersport11", "super sport 11 hd", "supersport 11 hd", "super sport 11 fhd"),
        "super sport 12" to listOf("super sport 12", "supersport 12", "super sport12", "supersport12", "super sport 12 hd", "supersport 12 hd", "super sport 12 fhd"),
        "star sports" to listOf("star sports", "star sport", "star sport 1", "star sport 2", "star sports hd", "star sport hd"),
        "star sports 1" to listOf("star sports 1", "star sport 1", "starsports 1", "star sports 1 hd", "star sport 1 hd", "star sports 1 fhd"),
        "star sports 2" to listOf("star sports 2", "star sport 2", "starsports 2", "star sports 2 hd", "star sport 2 hd", "star sports 2 fhd"),
        "star sports 3" to listOf("star sports 3", "star sport 3", "starsports 3", "star sports 3 hd", "star sport 3 hd", "star sports 3 fhd"),
        "star sports select" to listOf("star sports select", "star sport select", "star sports select hd1", "star sports select hd"),
        "sony sports" to listOf("sony sports", "sony sport", "sony ten", "sony ten 1", "sony ten 2", "sony ten 3", "sony sports hd", "sony sport hd"),
        "sony ten 1" to listOf("sony ten 1", "sonyten1", "sony 10 1", "sony sports 1", "sony ten 1 hd", "sony ten 1 fhd"),
        "sony ten 2" to listOf("sony ten 2", "sonyten2", "sony 10 2", "sony sports 2", "sony ten 2 hd", "sony ten 2 fhd"),
        "sony ten 3" to listOf("sony ten 3", "sonyten3", "sony 10 3", "sony sports 3", "sony ten 3 hd", "sony ten 3 fhd"),
        "sony ten 4" to listOf("sony ten 4", "sonyten4", "sony 10 4", "sony sports 4", "sony ten 4 hd", "sony ten 4 fhd"),
        "sony ten 5" to listOf("sony ten 5", "sonyten5", "sony 10 5", "sony sports 5", "sony ten 5 hd", "sony ten 5 fhd"),
        "trt spor" to listOf("trt spor", "trt sport", "trt sports", "trt spor hd", "trt sport hd"),
        "trt spor 1" to listOf("trt spor 1", "trt sport 1", "trt sports 1", "trt spor 1 hd", "trt sport 1 hd", "trt spor 1 fhd"),
        "trt spor 2" to listOf("trt spor 2", "trt sport 2", "trt sports 2", "trt spor 2 hd", "trt sport 2 hd", "trt spor 2 fhd"),
        "trt spor 3" to listOf("trt spor 3", "trt sport 3", "trt sports 3", "trt spor 3 hd", "trt sport 3 hd", "trt spor 3 fhd"),
        "spor smart" to listOf("spor smart", "sporsmart", "spor smart 1", "spor smart hd"),
        "a spor" to listOf("a spor", "aspor", "a sport", "a sports", "a spor hd", "a sport hd"),
        "a2" to listOf("a2", "a2 spor", "a2 sport", "a2 hd"),
        "a haber" to listOf("a haber", "ahaber", "a haber hd"),
        "a news" to listOf("a news", "anews", "a news hd"),
        "cnbc-e" to listOf("cnbc-e", "cnbc", "cnbce", "cnbc hd"),
        "bloomberg ht" to listOf("bloomberg ht", "bloomberg", "bloomberg hd"),
        "haber global" to listOf("haber global", "haberglobal", "haber global hd"),
        "haber türk" to listOf("haber türk", "haberturk", "haber türk hd"),
        "ntv" to listOf("ntv", "n tv", "ntv hd"),
        "kanal d" to listOf("kanal d", "kanald", "kanal d hd"),
        "show tv" to listOf("show tv", "showtv", "show tv hd"),
        "atv" to listOf("atv", "a tv", "atv hd"),
        "fox" to listOf("fox", "fox tv", "fox hd"),
        "star tv" to listOf("star tv", "startv", "star tv hd"),
        "tv8" to listOf("tv8", "tv 8", "tv8 hd"),
        "beyaz tv" to listOf("beyaz tv", "beyaztv", "beyaz tv hd"),
        "kanal 7" to listOf("kanal 7", "kanal7", "kanal 7 hd"),
        "teve2" to listOf("teve2", "teve 2", "teve2 hd"),
        "üç hilal tv" to listOf("üç hilal tv", "uchilal tv", "üç hilal tv hd"),
        "trt 1" to listOf("trt 1", "trt1", "trt 1 hd"),
        "trt haber" to listOf("trt haber", "trthaber", "trt haber hd"),
        "trt çocuk" to listOf("trt çocuk", "trtcocuk", "trt çocuk hd"),
        "trt belgesel" to listOf("trt belgesel", "trtbelgesel", "trt belgesel hd"),
        "trt müzik" to listOf("trt müzik", "trtmuzik", "trt müzik hd"),
        "trt avaz" to listOf("trt avaz", "trtavaz", "trt avaz hd"),
        "trt türk" to listOf("trt türk", "trtturk", "trt türk hd"),
        "trt kurdi" to listOf("trt kurdi", "trtkurdi", "trt kurdi hd"),
        "trt 2" to listOf("trt 2", "trt2", "trt 2 hd"),
        "trt 3" to listOf("trt 3", "trt3", "trt 3 hd"),
        "trt 4k" to listOf("trt 4k", "trt4k", "trt 4k hd"),
        "trt world" to listOf("trt world", "trtworld", "trt world hd"),
        "trt arabic" to listOf("trt arabic", "trtarabic", "trt arabic hd"),
        "trt eba tv" to listOf("trt eba tv", "trteba", "eba tv", "trt eba tv hd"),
        "euro d" to listOf("euro d", "eurod", "euro d hd"),
        "eurostar" to listOf("eurostar", "euro star", "eurostar hd"),
        "tlc" to listOf("tlc", "tlc tv", "tlc hd"),
        "discovery" to listOf("discovery", "discovery channel", "discovery channel hd", "discovery hd"),
        "discovery science" to listOf("discovery science", "discovery science hd"),
        "animal planet" to listOf("animal planet", "animal planet hd"),
        "national geographic" to listOf("national geographic", "nat geo", "natgeo", "national geographic hd", "nat geo hd"),
        "nat geo wild" to listOf("nat geo wild", "natgeowild", "national geographic wild", "nat geo wild hd"),
        "history" to listOf("history", "history channel", "history channel hd", "history hd"),
        "h2" to listOf("h2", "history 2", "history2", "h2 hd"),
        "crime investigation" to listOf("crime investigation", "crime investigation network", "ci network", "ci network hd"),
        "id" to listOf("id", "investigation discovery", "investigation discovery hd", "id hd"),
        "travel channel" to listOf("travel channel", "travel channel hd"),
        "food network" to listOf("food network", "food network hd"),
        "bbc earth" to listOf("bbc earth", "bbc earth hd"),
        "bbc first" to listOf("bbc first", "bbc first hd"),
        "bbc entertainment" to listOf("bbc entertainment", "bbc entertainment hd"),
        "bbc lifestyle" to listOf("bbc lifestyle", "bbc lifestyle hd"),
        "bbc world news" to listOf("bbc world news", "bbc world news hd"),
        "bbc news" to listOf("bbc news", "bbc news hd"),
        "bbc parliament" to listOf("bbc parliament", "bbc parliament hd"),
        "bbc two" to listOf("bbc two", "bbc 2", "bbc2", "bbc two hd"),
        "bbc three" to listOf("bbc three", "bbc 3", "bbc3", "bbc three hd"),
        "bbc four" to listOf("bbc four", "bbc 4", "bbc4", "bbc four hd"),
        "itv" to listOf("itv", "itv 1", "itv1", "itv hd", "itv 1 hd", "itv1 hd"),
        "itv 2" to listOf("itv 2", "itv2", "itv2 hd", "itv 2 hd"),
        "itv 3" to listOf("itv 3", "itv3", "itv3 hd", "itv 3 hd"),
        "itv 4" to listOf("itv 4", "itv4", "itv4 hd", "itv 4 hd"),
        "itv be" to listOf("itv be", "itvbe", "itv be hd"),
        "channel 4" to listOf("channel 4", "channel4", "ch 4", "channel 4 hd"),
        "channel 5" to listOf("channel 5", "channel5", "ch 5", "channel 5 hd"),
        "e4" to listOf("e4", "e 4", "e4 hd"),
        "more 4" to listOf("more 4", "more4", "more 4 hd"),
        "film4" to listOf("film4", "film 4", "film4 hd"),
        "dave" to listOf("dave", "dave channel", "dave hd"),
        "drama" to listOf("drama", "drama channel", "drama hd"),
        "yesterday" to listOf("yesterday", "yesterday channel", "yesterday hd"),
        "really" to listOf("really", "really channel", "really hd"),
        "alibi" to listOf("alibi", "alibi channel", "alibi hd"),
        "gold" to listOf("gold", "gold channel", "gold hd"),
        "w" to listOf("w", "w channel", "w hd"),
        "pick" to listOf("pick", "pick channel", "pick hd"),
        "5 star" to listOf("5 star", "5star", "5 star hd"),
        "5 usa" to listOf("5 usa", "5usa", "5 usa hd"),
        "5 select" to listOf("5 select", "5select", "5 select hd"),
        "sky one" to listOf("sky one", "sky 1", "sky1", "sky one hd", "sky 1 hd"),
        "sky two" to listOf("sky two", "sky 2", "sky2", "sky two hd", "sky 2 hd"),
        "sky atlantic" to listOf("sky atlantic", "sky atlantic hd"),
        "sky witness" to listOf("sky witness", "sky witness hd"),
        "sky comedy" to listOf("sky comedy", "sky comedy hd"),
        "sky sci-fi" to listOf("sky sci-fi", "sky sci fi", "sky scifi", "sky sci-fi hd"),
        "sky crime" to listOf("sky crime", "sky crime hd"),
        "sky history" to listOf("sky history", "sky history hd"),
        "sky arts" to listOf("sky arts", "sky arts hd"),
        "sky news" to listOf("sky news", "sky news hd"),
        "sky sports news" to listOf("sky sports news", "sky sports news hd"),
        "sky sports main event" to listOf("sky sports main event", "sky sports main event hd"),
        "sky sports premier league" to listOf("sky sports premier league", "sky sports premier league hd"),
        "sky sports football" to listOf("sky sports football", "sky sports football hd"),
        "sky sports cricket" to listOf("sky sports cricket", "sky sports cricket hd"),
        "sky sports golf" to listOf("sky sports golf", "sky sports golf hd"),
        "sky sports f1" to listOf("sky sports f1", "sky sports f1 hd"),
        "sky sports action" to listOf("sky sports action", "sky sports action hd"),
        "sky sports arena" to listOf("sky sports arena", "sky sports arena hd"),
        "sky sports mix" to listOf("sky sports mix", "sky sports mix hd"),
        "sky sports racing" to listOf("sky sports racing", "sky sports racing hd"),
        "sky sports nfl" to listOf("sky sports nfl", "sky sports nfl hd"),
        "sky sports box office" to listOf("sky sports box office", "sky sports box office hd"),
        "sky cinema premiere" to listOf("sky cinema premiere", "sky cinema premiere hd"),
        "sky cinema action" to listOf("sky cinema action", "sky cinema action hd"),
        "sky cinema comedy" to listOf("sky cinema comedy", "sky cinema comedy hd"),
        "sky cinema family" to listOf("sky cinema family", "sky cinema family hd"),
        "sky cinema drama" to listOf("sky cinema drama", "sky cinema drama hd"),
        "sky cinema sci-fi horror" to listOf("sky cinema sci-fi horror", "sky cinema scifi horror"),
        "sky cinema thriller" to listOf("sky cinema thriller", "sky cinema thriller hd"),
        "sky cinema select" to listOf("sky cinema select", "sky cinema select hd"),
        "sky cinema greats" to listOf("sky cinema greats", "sky cinema greats hd"),
        "sky cinema animation" to listOf("sky cinema animation", "sky cinema animation hd"),
        "sky cinema disney" to listOf("sky cinema disney", "sky cinema disney hd"),
        "sky cinema hits" to listOf("sky cinema hits", "sky cinema hits hd"),
        "now" to listOf("now", "now tv", "nowtv", "now hd"),
        "now sports" to listOf("now sports", "now sport", "nowtv sports", "now sports hd"),
        "now cinema" to listOf("now cinema", "nowtv cinema", "now cinema hd"),
        "now entertainment" to listOf("now entertainment", "nowtv entertainment", "now entertainment hd"),
        "now kids" to listOf("now kids", "nowtv kids", "now kids hd"),
        "netflix" to listOf("netflix", "netflix channel"),
        "amazon prime" to listOf("amazon prime", "prime video", "amazon prime video"),
        "disney+" to listOf("disney+", "disney plus", "disney"),
        "apple tv+" to listOf("apple tv+", "apple tv plus", "apple tv"),
        "hbo" to listOf("hbo", "hbo hd", "hbo channel"),
        "hbo max" to listOf("hbo max", "hbo max hd", "max"),
        "hulu" to listOf("hulu", "hulu channel"),
        "peacock" to listOf("peacock", "peacock tv", "peacock channel"),
        "paramount+" to listOf("paramount+", "paramount plus", "paramount"),
        "showtime" to listOf("showtime", "showtime hd", "showtime channel"),
        "starz" to listOf("starz", "starz hd", "starz channel"),
        "epix" to listOf("epix", "epix hd", "epix channel"),
        "amc" to listOf("amc", "amc hd", "amc channel"),
        "tnt" to listOf("tnt", "tnt hd", "tnt channel"),
        "tbs" to listOf("tbs", "tbs hd", "tbs channel"),
        "trutv" to listOf("trutv", "trutv hd", "tru tv"),
        "comedy central" to listOf("comedy central", "comedy central hd"),
        "mtv" to listOf("mtv", "mtv hd", "mtv channel"),
        "vh1" to listOf("vh1", "vh1 hd", "vh1 channel"),
        "bet" to listOf("bet", "bet hd", "bet channel"),
        "e!" to listOf("e!", "e entertainment", "e! entertainment"),
        "bravo" to listOf("bravo", "bravo hd", "bravo channel"),
        "fx" to listOf("fx", "fx hd", "fx channel"),
        "fxx" to listOf("fxx", "fxx hd", "fxx channel"),
        "syfy" to listOf("syfy", "syfy hd", "syfy channel"),
        "usa network" to listOf("usa network", "usa network hd", "usa"),
        "a&e" to listOf("a&e", "a&e hd", "a&e channel"),
        "lifetime" to listOf("lifetime", "lifetime hd", "lifetime channel"),
        "hallmark" to listOf("hallmark", "hallmark hd", "hallmark channel"),
        "hallmark movies & mysteries" to listOf("hallmark movies & mysteries", "hallmark movies mysteries"),
        "own" to listOf("own", "own hd", "own channel"),
        "we tv" to listOf("we tv", "we tv hd", "wetv"),
        "oxygen" to listOf("oxygen", "oxygen hd", "oxygen channel"),
        "investigation discovery" to listOf("investigation discovery", "investigation discovery hd", "id"),
        "cbs" to listOf("cbs", "cbs hd", "cbs channel"),
        "abc" to listOf("abc", "abc hd", "abc channel"),
        "nbc" to listOf("nbc", "nbc hd", "nbc channel"),
        "fox" to listOf("fox", "fox hd", "fox channel"),
        "cw" to listOf("cw", "cw hd", "cw channel"),
        "pbs" to listOf("pbs", "pbs hd", "pbs channel"),
        "univision" to listOf("univision", "univision hd", "univision channel"),
        "telemundo" to listOf("telemundo", "telemundo hd", "telemundo channel"),
        "azteca" to listOf("azteca", "azteca hd", "azteca channel"),
        "caracol" to listOf("caracol", "caracol hd", "caracol channel"),
        "rcn" to listOf("rcn", "rcn hd", "rcn channel"),
        "tv azteca" to listOf("tv azteca", "tv azteca hd", "tvazteca"),
        "las estrellas" to listOf("las estrellas", "las estrellas hd"),
        "imagen televisión" to listOf("imagen televisión", "imagen television", "imagen tv"),
        "multimedios" to listOf("multimedios", "multimedios hd", "multimedios tv"),
        "milenio" to listOf("milenio", "milenio hd", "milenio tv"),
        "foro tv" to listOf("foro tv", "foro tv hd", "foro"),
        "adn 40" to listOf("adn 40", "adn40", "adn tv"),
        "canal 5" to listOf("canal 5", "canal5", "c5"),
        "gala tv" to listOf("gala tv", "gala tv hd", "gala"),
        "azteca 7" to listOf("azteca 7", "azteca7", "az7"),
        "azteca 1" to listOf("azteca 1", "azteca1", "az1"),
        "azteca 13" to listOf("azteca 13", "azteca13", "az13"),
        "trece" to listOf("trece", "trece hd", "trece tv"),
        "cadenatres" to listOf("cadenatres", "cadena tres", "cadena 3"),
        "proyecto 40" to listOf("proyecto 40", "proyecto40", "p40"),
        "unicable" to listOf("unicable", "unicable hd", "unicable tv"),
        "distrito comedia" to listOf("distrito comedia", "distritocomedia"),
        "bitme" to listOf("bitme", "bitme hd", "bitme tv"),
        "az clic" to listOf("az clic", "azclic", "az clic tv"),
        "az corazón" to listOf("az corazón", "azcorazon", "az corazon tv"),
        "az cinema" to listOf("az cinema", "azcinema", "az cinema tv"),
        "az mundo" to listOf("az mundo", "azmundo", "az mundo tv"),
        "azteca deportes" to listOf("azteca deportes", "azteca deportes hd", "az deportes"),
        "tvc deportes" to listOf("tvc deportes", "tvc deportes hd", "tvc sports"),
        "tvc" to listOf("tvc", "tvc hd", "tvc channel"),
        "canal 11" to listOf("canal 11", "canal11", "c11"),
        "canal 13" to listOf("canal 13", "canal13", "c13"),
        "canal 2" to listOf("canal 2", "canal2", "c2"),
        "canal 4" to listOf("canal 4", "canal4", "c4"),
        "canal 6" to listOf("canal 6", "canal6", "c6"),
        "canal 7" to listOf("canal 7", "canal7", "c7"),
        "canal 9" to listOf("canal 9", "canal9", "c9"),
        "canal 10" to listOf("canal 10", "canal10", "c10"),
        "canal 12" to listOf("canal 12", "canal12", "c12"),
        "canal 14" to listOf("canal 14", "canal14", "c14"),
        "canal 15" to listOf("canal 15", "canal15", "c15"),
        "canal 16" to listOf("canal 16", "canal16", "c16"),
        "canal 17" to listOf("canal 17", "canal17", "c17"),
        "canal 18" to listOf("canal 18", "canal18", "c18"),
        "canal 19" to listOf("canal 19", "canal19", "c19"),
        "canal 20" to listOf("canal 20", "canal20", "c20"),
        "canal 21" to listOf("canal 21", "canal21", "c21"),
        "canal 22" to listOf("canal 22", "canal22", "c22"),
        "canal 23" to listOf("canal 23", "canal23", "c23"),
        "canal 24" to listOf("canal 24", "canal24", "c24"),
        "canal 25" to listOf("canal 25", "canal25", "c25"),
        "canal 26" to listOf("canal 26", "canal26", "c26"),
        "canal 27" to listOf("canal 27", "canal27", "c27"),
        "canal 28" to listOf("canal 28", "canal28", "c28"),
        "canal 29" to listOf("canal 29", "canal29", "c29"),
        "canal 30" to listOf("canal 30", "canal30", "c30"),
        "canal 31" to listOf("canal 31", "canal31", "c31"),
        "canal 32" to listOf("canal 32", "canal32", "c32"),
        "canal 33" to listOf("canal 33", "canal33", "c33"),
        "canal 34" to listOf("canal 34", "canal34", "c34"),
        "canal 35" to listOf("canal 35", "canal35", "c35"),
        "canal 36" to listOf("canal 36", "canal36", "c36"),
        "canal 37" to listOf("canal 37", "canal37", "c37"),
        "canal 38" to listOf("canal 38", "canal38", "c38"),
        "canal 39" to listOf("canal 39", "canal39", "c39"),
        "canal 40" to listOf("canal 40", "canal40", "c40"),
        "canal 41" to listOf("canal 41", "canal41", "c41"),
        "canal 42" to listOf("canal 42", "canal42", "c42"),
        "canal 43" to listOf("canal 43", "canal43", "c43"),
        "canal 44" to listOf("canal 44", "canal44", "c44"),
        "canal 45" to listOf("canal 45", "canal45", "c45"),
        "canal 46" to listOf("canal 46", "canal46", "c46"),
        "canal 47" to listOf("canal 47", "canal47", "c47"),
        "canal 48" to listOf("canal 48", "canal48", "c48"),
        "canal 49" to listOf("canal 49", "canal49", "c49"),
        "canal 50" to listOf("canal 50", "canal50", "c50")
    )

    // Sports-related keywords for group filtering
    private val sportsKeywords = listOf(
        "sport", "sports", "football", "soccer", "futbol", "bein", "ssc", "es",
        " premier", "champions", "ligue", "bundesliga", "serie a", "la liga",
        "match", "live", "game", "nfl", "nba", "mlb", "nhl", "ufc", "wwe",
        "euro", "world cup", "olympic", "fifa", "uefa", "espn", "sky sport",
        "bt sport", "dazn", "tnt sport", "arena sport", "eleven", "polsat sport",
        "super sport", "mbc pro", "prima sport", "trt spor", "on time", "kass",
        "alkass", "fox sport", "yas sport", "abu dhabi sport", "dubai sport",
        "spor", "futbol", "calcio", "tennis", "golf", "cricket", "rugby",
        "f1", "formula", "moto", "racing", "motor", "fight", "boxing", "mma"
    )

    private fun isSportsChannel(channel: Channel): Boolean {
        val text = (channel.name + " " + channel.category).lowercase()
        return sportsKeywords.any { text.contains(it) }
    }

    fun findChannelInSportsGroups(channelName: String?, allChannels: List<Channel>): Channel? {
        if (channelName.isNullOrBlank()) return null

        // Filter to sports channels only for faster matching
        val sportsChannels = allChannels.filter { isSportsChannel(it) }
        if (sportsChannels.isEmpty()) return null

        val normalized = channelName.trim().lowercase()
            .replace("|", "")
            .replace("ar", "")
            .replace("fhd", "")
            .replace("hd", "")
            .replace("sd", "")
            .replace("4k", "")
            .replace("uhd", "")
            .replace("  ", " ")
            .trim()

        // 1. Exact match in sports channels
        var found = sportsChannels.firstOrNull { it.name.trim().lowercase().replace("|", "").replace("ar", "").replace("fhd", "").replace("hd", "").replace("sd", "").replace("4k", "").replace("uhd", "").replace("  ", " ").trim() == normalized }
        if (found != null) return found

        // 2. Contains match in sports channels
        found = sportsChannels.firstOrNull { it.name.lowercase().replace("|", "").replace("ar", "").replace("fhd", "").replace("hd", "").replace("sd", "").replace("4k", "").replace("uhd", "").replace("  ", " ").trim().contains(normalized) }
        if (found != null) return found

        // 3. Known mapping fallback (search in sports channels)
        val knownName = knownMappings[normalized]
        if (knownName != null) {
            for (variant in knownName) {
                found = sportsChannels.firstOrNull { it.name.trim().lowercase() == variant }
                if (found != null) return found
                found = sportsChannels.firstOrNull { it.name.lowercase().contains(variant) }
                if (found != null) return found
            }
        }

        // 4. Keyword fuzzy search in sports channels
        val keywords = normalized.split(" ").filter { it.length > 2 }
        if (keywords.isNotEmpty()) {
            found = sportsChannels.firstOrNull { ch ->
                keywords.any { kw -> ch.name.lowercase().contains(kw) }
            }
            if (found != null) return found
        }

        return null
    }

    // Legacy method for non-sports fallback
    fun findChannel(channelName: String?, allChannels: List<Channel>): Channel? {
        return findChannelInSportsGroups(channelName, allChannels)
            ?: findChannelAny(channelName, allChannels)
    }

    private fun findChannelAny(channelName: String?, allChannels: List<Channel>): Channel? {
        if (channelName.isNullOrBlank()) return null
        val normalized = channelName.trim().lowercase()
        var found = allChannels.firstOrNull { it.name.trim().lowercase() == normalized }
        if (found != null) return found
        found = allChannels.firstOrNull { it.name.lowercase().contains(normalized) }
        if (found != null) return found
        val keywords = normalized.split(" ").filter { it.length > 2 }
        if (keywords.isNotEmpty()) {
            found = allChannels.firstOrNull { ch -> keywords.any { kw -> ch.name.lowercase().contains(kw) } }
            if (found != null) return found
        }
        return null
    }
}
