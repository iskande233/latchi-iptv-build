package com.latchi.iptv.adapter

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.latchi.iptv.R
import com.latchi.iptv.model.Channel

class ChannelsAdapter(
    private var channels: List<Channel>,
    private val isFavorite: (Channel) -> Boolean,
    private val onFavoriteClicked: (Channel) -> Unit,
    private val onChannelClicked: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelsAdapter.ChannelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) = holder.bind(channels[position])
    override fun getItemCount(): Int = channels.size

    fun updateChannels(newChannels: List<Channel>) {
        val diffResult = DiffUtil.calculateDiff(ChannelDiffCallback(channels, newChannels))
        channels = newChannels
        diffResult.dispatchUpdatesTo(this)
    }

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val logoImageView: ImageView = itemView.findViewById(R.id.logoImageView)
        private val nameTextView: TextView = itemView.findViewById(R.id.nameTextView)
        private val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
        private val typeBadgeTextView: TextView = itemView.findViewById(R.id.typeBadgeTextView)
        private val favoriteButton: ImageView = itemView.findViewById(R.id.favoriteButton)
        private val epgTextView: android.widget.TextView = itemView.findViewById(R.id.epgTextView)

        private val longPressHandler = Handler(Looper.getMainLooper())
        private var longPressRunnable: Runnable? = null
        private var isLongPress = false

        fun bind(channel: Channel) {
            nameTextView.text = channel.name
            categoryTextView.text = channel.category

            renderFavorite(isFavorite(channel))

            when (channel.contentType) {
                "movie" -> { typeBadgeTextView.text = "MOVIE"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#7C3AED")) }
                "series" -> { typeBadgeTextView.text = "SERIES"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#DB2777")) }
                else -> { typeBadgeTextView.text = "LIVE"; typeBadgeTextView.setBackgroundColor(Color.parseColor("#16A34A")) }
            }

            Glide.with(itemView.context)
                .load(channel.logoUrl.ifBlank { null })
                .placeholder(R.drawable.ic_tv)
                .error(R.drawable.ic_tv)
                .into(logoImageView)

            // Small heart button: direct click for all devices
            favoriteButton.setOnClickListener {
                onFavoriteClicked(channel)
                val nowFav = isFavorite(channel)
                renderFavorite(nowFav)
                animateHeart(favoriteButton, nowFav)
            }

            val isTv = com.latchi.iptv.utils.TvUtils.isTv(itemView.context)

            if (isTv) {
                // Android TV: SINGLE click = open channel, long press = favorite
                itemView.isLongClickable = true
                itemView.setOnClickListener {
                    onChannelClicked(channel)
                }
                itemView.setOnLongClickListener {
                    performFavoriteToggle(channel)
                    itemView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    true
                }
            } else {
                // Phone/Tablet: single tap opens channel, long press toggles favorite
                itemView.setOnClickListener {
                    onChannelClicked(channel)
                }
                itemView.setOnLongClickListener {
                    performFavoriteToggle(channel)
                    itemView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    true
                }
                // Also support touch-hold (1 second) for favorite
                itemView.setOnTouchListener { v, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            isLongPress = false
                            longPressRunnable = Runnable {
                                isLongPress = true
                                performFavoriteToggle(channel)
                                v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            }
                            longPressHandler.postDelayed(longPressRunnable!!, 500)
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            longPressRunnable?.let { longPressHandler.removeCallbacks(it) }
                            if (!isLongPress) {
                                // It's a short tap -> perform click
                                v.performClick()
                            }
                            isLongPress = false
                            true
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            longPressRunnable?.let { longPressHandler.removeCallbacks(it) }
                            isLongPress = false
                            true
                        }
                        else -> false
                    }
                }
            }
        }

        private fun performFavoriteToggle(channel: Channel) {
            onFavoriteClicked(channel)
            val nowFav = isFavorite(channel)
            renderFavorite(nowFav)
            animateHeart(favoriteButton, nowFav)
            val msg = if (nowFav) itemView.context.getString(R.string.added_to_favorites)
                      else itemView.context.getString(R.string.removed_from_favorites)
            Toast.makeText(itemView.context, msg, Toast.LENGTH_SHORT).show()
        }

        private fun renderFavorite(fav: Boolean) {
            favoriteButton.setImageResource(
                if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
        }

        private fun animateHeart(view: View, added: Boolean) {
            val peak = if (added) 1.6f else 1.3f
            view.animate().cancel()
            view.scaleX = 0.7f
            view.scaleY = 0.7f
            view.animate()
                .scaleX(peak).scaleY(peak)
                .setDuration(140)
                .setInterpolator(OvershootInterpolator(3f))
                .withEndAction {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                }
                .start()
        }
    }

    private class ChannelDiffCallback(private val oldList: List<Channel>, private val newList: List<Channel>) : DiffUtil.Callback() {
        override fun getOldListSize(): Int = oldList.size
        override fun getNewListSize(): Int = newList.size
        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].streamUrl == newList[newItemPosition].streamUrl
        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]
    }
}
