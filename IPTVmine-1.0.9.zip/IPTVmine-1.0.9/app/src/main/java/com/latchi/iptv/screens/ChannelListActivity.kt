package com.latchi.iptv.screens

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R
import com.latchi.iptv.adapter.ChannelsAdapter
import com.latchi.iptv.model.Channel
import com.latchi.iptv.provider.ChannelsProvider
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.FavoritesPrefs
import com.latchi.iptv.utils.SourcePrefs

class ChannelListActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(com.latchi.iptv.utils.LocaleHelper.wrap(newBase))
    }

    private lateinit var channelsProvider: ChannelsProvider
    private lateinit var adapter: ChannelsAdapter
    private lateinit var titleText: TextView
    private lateinit var menuButton: TextView
    private lateinit var refreshButton: TextView
    private lateinit var categoryButton: TextView
    private lateinit var closeCategoriesButton: TextView
    private lateinit var searchEditText: EditText
    private lateinit var categorySearchEditText: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private lateinit var categoryPanel: LinearLayout
    private lateinit var categoryContainer: LinearLayout
    private lateinit var countdownText: TextView
    private lateinit var drawerLayout: DrawerLayout

    private var contentType = "live"
    private var screenTitle = "LIVE TV"
    private var currentQuery = ""
    private var categoryQuery = ""
    private var currentCategory = "All"
    private var debounceHandler: Handler? = null
    private var categoryDebounceHandler: Handler? = null
    private var saveAfterFetch = false
    private var lastChannels: List<Channel> = emptyList()

    companion object {
        private const val EXTRA_TYPE = "extra_type"
        private const val EXTRA_TITLE = "extra_title"
        fun start(context: Context, type: String, title: String) {
            val intent = Intent(context, ChannelListActivity::class.java).apply {
                putExtra(EXTRA_TYPE, type)
                putExtra(EXTRA_TITLE, title)
            }
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.latchi.iptv.utils.TvUtils.applyOrientation(this)
        com.latchi.iptv.utils.ThemeManager.apply(this)
        setContentView(R.layout.activity_channel_list)

        contentType = intent.getStringExtra(EXTRA_TYPE) ?: "live"
        screenTitle = intent.getStringExtra(EXTRA_TITLE) ?: "LIVE TV"

        channelsProvider = ViewModelProvider(this)[ChannelsProvider::class.java]
        titleText = findViewById(R.id.titleText)
        menuButton = findViewById(R.id.menuButton)
        refreshButton = findViewById(R.id.refreshButton)
        categoryButton = findViewById(R.id.categoryButton)
        closeCategoriesButton = findViewById(R.id.closeCategoriesButton)
        searchEditText = findViewById(R.id.searchEditText)
        categorySearchEditText = findViewById(R.id.categorySearchEditText)
        progressBar = findViewById(R.id.progressBar)
        recyclerView = findViewById(R.id.recyclerView)
        categoryPanel = findViewById(R.id.categoryPanel)
        categoryContainer = findViewById(R.id.categoryContainer)
        countdownText = findViewById(R.id.countdownText)
        drawerLayout = findViewById(R.id.drawerLayout)

        titleText.text = screenTitle

        adapter = ChannelsAdapter(
            emptyList(),
            isFavorite = { channel -> activeId()?.let { FavoritesPrefs.isFavorite(this, it, channel.streamUrl) } ?: false },
            onFavoriteClicked = { channel -> activeId()?.let { FavoritesPrefs.toggle(this, it, channel.streamUrl); applyFilter() } },
            onChannelClicked = { channel: Channel ->
                when {
                    channel.contentType == "series" || channel.streamUrl.startsWith("series://") -> {
                        val active = SourcePrefs.getActiveProfile(this)
                        if (active != null) {
                            SeriesDetailActivity.start(this, channel, active.m3uUrl)
                        } else {
                            Toast.makeText(this, getString(R.string.series_not_available), Toast.LENGTH_SHORT).show()
                        }
                    }
                    channel.contentType == "movie" -> {
                        MovieDetailActivity.start(this, channel)
                    }
                    else -> {
                        PlayerActivity.start(this, channel)
                    }
                }
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        setupDrawer()
        menuButton.setOnClickListener { finish() }; menuButton.text = ""; menuButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_arrow_back, 0, 0, 0); menuButton.setPadding(16,8,16,8)
        refreshButton.visibility = android.view.View.GONE
        categoryButton.setOnClickListener { openCategories() }
        closeCategoriesButton.setOnClickListener { closeCategories() }

        setupSearch()
        setupCategorySearch()
        setupObservers()
        loadCachedOrFetch()
        startCountdown()
    }

    private fun setupDrawer() {
        findViewById<TextView>(R.id.drawerTodaysMatches).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, MatchesActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerLogout).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            val intent = Intent(this, UserListActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }

    private fun activeId(): String? = SourcePrefs.getActiveProfile(this)?.id

    private fun openCategories() {
        categoryPanel.visibility = View.VISIBLE
        if (com.latchi.iptv.utils.TvUtils.isTv(this)) {
            categoryPanel.post {
                if (categoryContainer.childCount > 0) {
                    categoryContainer.getChildAt(0)?.requestFocus()
                }
            }
        }
    }

    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                debounceHandler?.removeCallbacksAndMessages(null)
                debounceHandler = Handler(Looper.getMainLooper())
                debounceHandler?.postDelayed({ currentQuery = s.toString(); applyFilter() }, 300)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupCategorySearch() {
        categorySearchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                categoryDebounceHandler?.removeCallbacksAndMessages(null)
                categoryDebounceHandler = Handler(Looper.getMainLooper())
                categoryDebounceHandler?.postDelayed({
                    categoryQuery = s.toString()
                    buildCategories(lastChannels)
                }, 250)
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun setupObservers() {
        channelsProvider.channels.observe(this, Observer { data ->
            progressBar.visibility = View.GONE
            lastChannels = data
            if (saveAfterFetch) {
                val active = SourcePrefs.getActiveProfile(this)
                if (active != null && data.isNotEmpty()) ChannelCache.save(this, active.id, data)
                saveAfterFetch = false
            }
            buildCategories(data)
            applyFilter()
        })
        channelsProvider.filteredChannels.observe(this, Observer { data -> adapter.updateChannels(data) })
        channelsProvider.error.observe(this, Observer { error ->
            if (!error.isNullOrBlank()) {
                progressBar.visibility = View.GONE
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun loadCachedOrFetch() {
        val active = SourcePrefs.getActiveProfile(this)
        if (active == null) {
            startActivity(Intent(this, UserListActivity::class.java).putExtra("show_settings", true))
            finish()
            return
        }
        val cached = ChannelCache.load(this, active.id)
        if (cached.isNotEmpty()) channelsProvider.setLocalChannels(cached) else forceUpdate()
    }

    private fun forceUpdate() {
        val active = SourcePrefs.getActiveProfile(this) ?: return
        saveAfterFetch = true
        progressBar.visibility = View.VISIBLE
        channelsProvider.fetchM3UFile(active.m3uUrl)
    }

    private fun buildCategories(data: List<Channel>) {
        categoryContainer.removeAllViews()
        val filtered = data.filter { it.contentType == contentType }
        val cats = mutableListOf("All", "Favorites")
        cats.addAll(filtered.map { it.category }.distinct().sorted())

        val visibleCats = if (categoryQuery.isBlank()) cats else cats.filter { it.contains(categoryQuery, ignoreCase = true) }

        val isTv = com.latchi.iptv.utils.TvUtils.isTv(this)
        val isRtl = resources.configuration.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL

        visibleCats.forEachIndexed { index, cat ->
            val count = when (cat) {
                "All" -> filtered.size
                "Favorites" -> activeId()?.let { FavoritesPrefs.getFavorites(this, it).size } ?: 0
                else -> filtered.count { it.category == cat }
            }
            val displayName = when (cat) {
                "All" -> getString(R.string.all)
                "Favorites" -> getString(R.string.favorites)
                else -> cat
            }
            val tv = TextView(this).apply {
                text = "$displayName   $count"
                textSize = 14f
                setTextColor(android.graphics.Color.WHITE)
                setPadding(18, 12, 18, 12)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                isFocusable = true
                isFocusableInTouchMode = true
                isClickable = true
                foreground = androidx.core.content.ContextCompat.getDrawable(this@ChannelListActivity, R.drawable.focus_ring)
                setBackgroundResource(if (cat == currentCategory) R.drawable.bg_button_primary else R.drawable.bg_panel)

                if (isTv) {
                    if (isRtl) {
                        nextFocusLeftId = R.id.recyclerView
                    } else {
                        nextFocusRightId = R.id.recyclerView
                    }
                    if (index == 0) {
                        nextFocusUpId = R.id.categorySearchEditText
                    }
                }

                setOnClickListener {
                    currentCategory = cat
                    closeCategories()
                    buildCategories(data)
                    applyFilter()
                }
            }
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.setMargins(0, 0, 0, 8)
            categoryContainer.addView(tv, params)
        }
    }

    private fun applyFilter() {
        val favs = activeId()?.let { FavoritesPrefs.getFavorites(this, it) } ?: emptySet()
        channelsProvider.filterChannels(currentQuery, contentType, currentCategory, favs)
    }

    private fun closeCategories() {
        categoryPanel.visibility = View.GONE
        if (com.latchi.iptv.utils.TvUtils.isTv(this)) {
            recyclerView.requestFocus()
        }
    }

    private fun startCountdown() {
        val active = SourcePrefs.getActiveProfile(this) ?: return
        val expires = active.expiresAt
        if (expires.isBlank()) return
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
            val endDate = sdf.parse("$expires 23:59:59") ?: return
            val handler = Handler(Looper.getMainLooper())
            val runnable = object : Runnable {
                override fun run() {
                    val diff = endDate.time - System.currentTimeMillis()
                    if (diff <= 0) {
                        countdownText.text = getString(R.string.expired)
                        countdownText.visibility = View.VISIBLE
                        return
                    }
                    val hours = diff / (1000 * 60 * 60)
                    val minutes = (diff % (1000 * 60 * 60)) / (1000 * 60)
                    val seconds = (diff % (1000 * 60)) / 1000
                    countdownText.text = "⏳ ${String.format("%02d:%02d:%02d", hours, minutes, seconds)}"
                    countdownText.visibility = View.VISIBLE
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(runnable)
        } catch (_: Exception) { }
    }

    @Deprecated("Deprecated in Java")
    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        when (keyCode) {
            android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (categoryPanel.visibility != android.view.View.VISIBLE) {
                    openCategories()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END)
        } else if (categoryPanel.visibility == View.VISIBLE) {
            closeCategories()
        } else {
            super.onBackPressed()
        }
    }
}
