package com.latchi.iptv.utils

object ActivationConfig {
    const val ACTIVATION_API_URL = "https://script.google.com/macros/s/AKfycbxbPxWCm5AQTDaIJTod1_hXVwy49QLaTUaNfRFs5ZA9OTekePEPcU4KRdk3ZFqDEh2R/exec"
}
