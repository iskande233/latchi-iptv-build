package com.latchi.iptv.screens

import android.content.Intent
import com.latchi.iptv.MainActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.latchi.iptv.R

class SplashActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(com.latchi.iptv.utils.LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.latchi.iptv.utils.TvUtils.applyOrientation(this)
        hideSystemUi()
        setContentView(R.layout.activity_splash)

        val splashImage = findViewById<ImageView>(R.id.splashImage)
        val isLandscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels

        val prefs = getSharedPreferences("splash_prefs", MODE_PRIVATE)
        val lastWasIslamic = prefs.getBoolean("last_islamic", false)
        val useIslamic = !lastWasIslamic
        prefs.edit().putBoolean("last_islamic", useIslamic).apply()

        val splashRes = when {
            useIslamic && isLandscape -> R.drawable.splash_islamic_tv
            useIslamic && !isLandscape -> R.drawable.splash_islamic_phone
            isLandscape -> R.drawable.splash_tv
            else -> R.drawable.splash_phone
        }
        splashImage.setImageResource(splashRes)

        Handler(Looper.getMainLooper()).postDelayed({
            // Always go to UserList (activation page) first
            startActivity(Intent(this, if (com.latchi.iptv.utils.SourcePrefs.hasActiveProfile(this)) MainActivity::class.java else UserListActivity::class.java))
            finish()
        }, 5000)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }
}
