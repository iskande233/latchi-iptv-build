package com.latchi.iptv.screens

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.latchi.iptv.MainActivity
import com.latchi.iptv.R
import com.latchi.iptv.utils.ChannelCache
import com.latchi.iptv.utils.LanguagePrefs
import com.latchi.iptv.utils.LocaleHelper
import com.latchi.iptv.utils.PlayerPrefs
import com.latchi.iptv.utils.SourcePrefs

class SettingsActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    private lateinit var languageText: TextView
    private lateinit var playerModeText: TextView
    private lateinit var expiryInfoText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.latchi.iptv.utils.TvUtils.applyOrientation(this)
        com.latchi.iptv.utils.ThemeManager.apply(this)
        setContentView(R.layout.activity_settings)

        languageText = findViewById(R.id.languageText)
        playerModeText = findViewById(R.id.playerModeText)
        expiryInfoText = findViewById(R.id.expiryInfoText)

        findViewById<TextView>(R.id.backButton).setOnClickListener { finish() }
        findViewById<TextView>(R.id.langArabic).setOnClickListener { setLang("ar") }
        findViewById<TextView>(R.id.langFrench).setOnClickListener { setLang("fr") }
        findViewById<TextView>(R.id.langEnglish).setOnClickListener { setLang("en") }
        findViewById<TextView>(R.id.playerAuto).setOnClickListener { setPlayerMode(PlayerPrefs.MODE_AUTO) }
        findViewById<TextView>(R.id.playerHls).setOnClickListener { setPlayerMode(PlayerPrefs.MODE_HLS) }
        findViewById<TextView>(R.id.playerProgressive).setOnClickListener { setPlayerMode(PlayerPrefs.MODE_PROGRESSIVE) }

        findViewById<TextView>(R.id.supportButton).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/213798712450")))
        }
        findViewById<TextView>(R.id.changeUserButton).setOnClickListener {
            startActivity(Intent(this, UserListActivity::class.java).putExtra("show_settings", true))
            finish()
        }
        findViewById<TextView>(R.id.manualButton).setOnClickListener {
            startActivity(Intent(this, ManualSourceActivity::class.java))
        }
        findViewById<TextView>(R.id.clearCacheButton).setOnClickListener {
            val active = SourcePrefs.getActiveProfile(this)
            if (active != null) {
                ChannelCache.clear(this, active.id)
                Toast.makeText(this, getString(R.string.cache_cleared), Toast.LENGTH_SHORT).show()
            }
        }
        updateLanguageText()
        updatePlayerText()
        updateExpiryInfo()
    }

    private fun setLang(lang: String) {
        if (LanguagePrefs.getLanguage(this) == lang) return
        LanguagePrefs.setLanguage(this, lang)
        Toast.makeText(this, getString(R.string.language_saved), Toast.LENGTH_SHORT).show()
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun updateLanguageText() {
        languageText.text = "${getString(R.string.language)}: ${LanguagePrefs.getLanguageName(this)}"
    }

    private fun setPlayerMode(mode: String) {
        PlayerPrefs.setMode(this, mode)
        updatePlayerText()
        Toast.makeText(this, getString(R.string.player_saved), Toast.LENGTH_SHORT).show()
    }

    private fun updatePlayerText() {
        playerModeText.text = "${getString(R.string.player_mode)}: ${PlayerPrefs.getModeLabel(this)}"
    }

    private fun updateExpiryInfo() {
        val active = SourcePrefs.getActiveProfile(this)
        if (active == null) {
            expiryInfoText.text = getString(R.string.logged_in) + ": -"
            return
        }
        val expiry = active.expiresAt
        val code = active.activationCode
        val name = active.name
        val info = buildString {
            append("${getString(R.string.logged_in)}: $name\n")
            if (code.isNotBlank() && code != "MANUAL") {
                append("${getString(R.string.expiry)}: $expiry\n")
                append("Code: $code")
            }
        }
        expiryInfoText.text = info
    }
}
