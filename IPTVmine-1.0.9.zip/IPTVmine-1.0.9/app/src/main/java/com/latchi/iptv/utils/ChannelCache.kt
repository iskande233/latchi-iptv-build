package com.latchi.iptv.utils

import android.content.Context
import com.latchi.iptv.model.Channel
import org.json.JSONArray
import org.json.JSONObject

object ChannelCache {
    private const val PREFS_NAME = "iptv_channel_cache"

    fun save(context: Context, profileId: String, channels: List<Channel>) {
        val arr = JSONArray()
        channels.forEach { c ->
            arr.put(JSONObject().apply {
                put("name", c.name)
                put("logoUrl", c.logoUrl)
                put("streamUrl", c.streamUrl)
                put("category", c.category)
                put("contentType", c.contentType)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString("channels_$profileId", arr.toString())
            .putLong("updated_$profileId", System.currentTimeMillis())
            .apply()
    }

    fun load(context: Context, profileId: String): List<Channel> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString("channels_$profileId", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<Channel>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                Channel(
                    name = o.optString("name"),
                    logoUrl = o.optString("logoUrl"),
                    streamUrl = o.optString("streamUrl"),
                    category = o.optString("category", "Other"),
                    contentType = o.optString("contentType", "live")
                )
            )
        }
        return list
    }

    fun updatedAt(context: Context, profileId: String): Long {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getLong("updated_$profileId", 0L)
    }

    fun clear(context: Context, profileId: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .remove("channels_$profileId")
            .remove("updated_$profileId")
            .apply()
    }
}
