package com.latchi.iptv.utils

import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

data class ActivationValidationResult(
    val success: Boolean,
    val message: String,
    val name: String = "",
    val playlistUrl: String = "",
    val expiresAt: String = "",
    val maxDevices: Int = 1
)

object ActivationValidator {
    fun validate(context: Context, profile: IptvProfile): ActivationValidationResult {
        if (profile.activationCode == "MANUAL") {
            return ActivationValidationResult(true, "OK", profile.name, profile.m3uUrl, profile.expiresAt, profile.maxDevices)
        }

        val apiUrl = ActivationConfig.ACTIVATION_API_URL
        if (apiUrl.contains("PASTE_GOOGLE")) {
            return ActivationValidationResult(false, "Activation API not configured")
        }

        val deviceId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val code = URLEncoder.encode(profile.activationCode, "UTF-8")
        val device = URLEncoder.encode(deviceId, "UTF-8")
        val requestUrl = "$apiUrl?code=$code&device_id=$device"

        val connection = URL(requestUrl).openConnection() as HttpURLConnection
        connection.requestMethod = "GET"
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")

        val response = connection.inputStream.bufferedReader().use(BufferedReader::readText)
        val json = JSONObject(response)
        val success = json.optBoolean("success", false)
        if (!success) {
            return ActivationValidationResult(false, json.optString("message", "Activation failed"))
        }

        return ActivationValidationResult(
            success = true,
            message = "OK",
            name = json.optString("name", profile.name),
            playlistUrl = json.optString("playlist_url", profile.m3uUrl).replace("&amp;", "&"),
            expiresAt = json.optString("expires_at", profile.expiresAt),
            maxDevices = json.optInt("max_devices", profile.maxDevices)
        )
    }
}
