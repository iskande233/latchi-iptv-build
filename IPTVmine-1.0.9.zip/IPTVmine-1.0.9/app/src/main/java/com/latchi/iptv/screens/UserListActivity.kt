package com.latchi.iptv.screens

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.latchi.iptv.MainActivity
import com.latchi.iptv.R
import com.latchi.iptv.utils.ActivationConfig
import com.latchi.iptv.utils.SourcePrefs
import com.latchi.iptv.utils.ThemeManager
import org.json.JSONObject
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread

class UserListActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: android.content.Context) {
        super.attachBaseContext(com.latchi.iptv.utils.LocaleHelper.wrap(newBase))
    }

    private lateinit var codeInput: EditText
    private lateinit var activateCodeButton: TextView
    private lateinit var addM3uButton: TextView
    private lateinit var addXtreamButton: TextView
    private lateinit var noCodeButton: TextView
    private lateinit var profileCard: LinearLayout
    private lateinit var profileImage: ImageView
    private lateinit var profileName: TextView
    private lateinit var playButton: LinearLayout
    private lateinit var deleteProfileButton: LinearLayout
    private lateinit var activationSection: LinearLayout
    private lateinit var manualSection: LinearLayout
    private lateinit var exitAppButton: LinearLayout
    private lateinit var drawerLayout: DrawerLayout

    private var activeProfile: com.latchi.iptv.utils.IptvProfile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.latchi.iptv.utils.TvUtils.applyOrientation(this)
        ThemeManager.apply(this)
        setContentView(R.layout.activity_user_list)

        codeInput = findViewById(R.id.codeInput)
        activateCodeButton = findViewById(R.id.activateCodeButton)
        addM3uButton = findViewById(R.id.addM3uButton)
        addXtreamButton = findViewById(R.id.addXtreamButton)
        noCodeButton = findViewById(R.id.noCodeButton)
        profileCard = findViewById(R.id.profileCard)
        profileImage = findViewById(R.id.profileImage)
        profileName = findViewById(R.id.profileName)
        playButton = findViewById(R.id.playButton)
        deleteProfileButton = findViewById(R.id.deleteProfileButton)
        activationSection = findViewById(R.id.activationSection)
        manualSection = findViewById(R.id.manualSection)
        exitAppButton = findViewById(R.id.exitAppButton)
        drawerLayout = findViewById(R.id.drawerLayout)

        setupDrawer()

        activateCodeButton.setOnClickListener { activateCode() }
        addM3uButton.setOnClickListener { openAddM3u() }
        addXtreamButton.setOnClickListener { openAddXtream() }
        noCodeButton.setOnClickListener { openWhatsApp() }
        playButton.setOnClickListener { goToMain() }
        deleteProfileButton.setOnClickListener {
            activeProfile?.let { profile ->
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.confirm_delete))
                    .setMessage(getString(R.string.delete_profile_confirm, profile.name))
                    .setPositiveButton(getString(R.string.delete)) { _, _ ->
                        SourcePrefs.deleteProfile(this, profile.id)
                        refreshScreen()
                    }
                    .setNegativeButton(getString(R.string.cancel), null)
                    .show()
            }
        }
        exitAppButton.setOnClickListener { finishAffinity() }

        profileImage.setOnClickListener { pickProfileImage() }
    }

    override fun onResume() {
        super.onResume()
        refreshScreen()
    }

    private fun setupDrawer() {
        findViewById<TextView>(R.id.menuButton).setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.END)
        }
        findViewById<TextView>(R.id.drawerMatches).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, MatchesActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerPrayer).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, PrayerActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerPricing).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, PricingActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerThemeSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, ThemeSettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerSettings).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<TextView>(R.id.drawerAbout).setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.END)
            showAboutDialog()
        }
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.app_info_title))
            .setMessage(getString(R.string.app_info_desc))
            .setPositiveButton(getString(R.string.close), null)
            .show()
    }

    private fun refreshScreen() {
        activeProfile = SourcePrefs.getActiveProfile(this)

        val forceManual = intent.getBooleanExtra("show_settings", false)

        if (activeProfile != null && !forceManual) {
            showLoadingThenGoToMain()
            return
        }

        if (activeProfile != null && !forceManual) {
            profileCard.visibility = View.VISIBLE
            activationSection.visibility = View.GONE
            manualSection.visibility = View.GONE
            profileName.text = activeProfile!!.name
            loadProfileImage()
        } else {
            // Show M3U + Xtream input fields (this is what user wants)
            profileCard.visibility = View.GONE
            activationSection.visibility = View.VISIBLE
            manualSection.visibility = View.VISIBLE
        }
    }
    }

    private fun loadProfileImage() {
        val uri = getSharedPreferences("profile_prefs", MODE_PRIVATE)
            .getString("profile_image", null)
        if (uri != null) {
            try {
                profileImage.setImageURI(android.net.Uri.parse(uri))
            } catch (_: Exception) {
                profileImage.setImageResource(R.drawable.ic_tv)
            }
        }
    }

    private fun pickProfileImage() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!.toString()
            getSharedPreferences("profile_prefs", MODE_PRIVATE).edit()
                .putString("profile_image", uri).apply()
            profileImage.setImageURI(data.data)
        }
    }

    private fun goToMain() {
        activeProfile?.let { profile ->
            SourcePrefs.setActiveProfile(this, profile.id)
            showLoadingThenGoToMain()
        }
    }

    private fun showLoadingThenGoToMain() {
        setContentView(R.layout.activity_loading)
        val progressBar = findViewById<ProgressBar>(R.id.loadingProgress)
        val percentText = findViewById<TextView>(R.id.loadingPercent)
        val statusText = findViewById<TextView>(R.id.loadingText)

        statusText.text = "LOADING ..."

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            var progress = 0
            val runnable = object : Runnable {
                override fun run() {
                    progress += 20
                    progressBar.progress = progress
                    percentText.text = "$progress%"
                    if (progress < 100) {
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this, 400)
                    } else {
                        startActivity(Intent(this@UserListActivity, MainActivity::class.java))
                        finish()
                    }
                }
            }
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(runnable, 400)
        }, 200)
    }

    private fun openWhatsApp() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/213798712450?text=مرحبا، أريد شراء كود تفعيل لتطبيق LATCHI IPTV")))
        } catch (_: Exception) {
            Toast.makeText(this, getString(R.string.whatsapp_error), Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAddM3u() {
        val intent = Intent(this, ActivationActivity::class.java)
        intent.putExtra("mode", "m3u")
        startActivity(intent)
    }

    private fun openAddXtream() {
        val intent = Intent(this, ActivationActivity::class.java)
        intent.putExtra("mode", "xtream")
        startActivity(intent)
    }

    private fun activateCode() {
        val code = codeInput.text.toString().trim()
        if (code.length < 4) {
            Toast.makeText(this, getString(R.string.invalid_code), Toast.LENGTH_SHORT).show()
            return
        }
        if (ActivationConfig.ACTIVATION_API_URL.contains("PASTE_GOOGLE")) {
            Toast.makeText(this, getString(R.string.api_not_configured), Toast.LENGTH_SHORT).show()
            return
        }

        activateCodeButton.isEnabled = false
        val dialog = AlertDialog.Builder(this)
            .setTitle(getString(R.string.checking_subscription))
            .setView(ProgressBar(this))
            .setCancelable(false)
            .create()
        dialog.show()

        thread {
            try {
                val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
                val url = "${ActivationConfig.ACTIVATION_API_URL}?code=$code&device_id=$deviceId"
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 15000
                connection.readTimeout = 20000
                val response = connection.inputStream.bufferedReader().use(BufferedReader::readText)
                val json = JSONObject(response)
                val success = json.optBoolean("success", false)
                val playlistUrl = json.optString("playlist_url", "")
                val expiresAt = json.optString("expires_at", "")
                val serverName = json.optString("name", "")
                runOnUiThread {
                    dialog.dismiss()
                    activateCodeButton.isEnabled = true
                    if (success) {
                        if (playlistUrl.isBlank()) {
                            Toast.makeText(this, getString(R.string.empty_playlist), Toast.LENGTH_SHORT).show()
                            return@runOnUiThread
                        }
                        showNameDialog(code, playlistUrl, expiresAt, serverName)
                    } else {
                        Toast.makeText(this, json.optString("message", getString(R.string.invalid_code)), Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dialog.dismiss()
                    activateCodeButton.isEnabled = true
                    Toast.makeText(this, e.localizedMessage ?: getString(R.string.activation_failed), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showNameDialog(code: String, playlistUrl: String, expiresAt: String, serverName: String) {
        // Auto-save and go to loading directly
        val autoName = serverName.ifBlank { "User ${'$'}code" }
        SourcePrefs.saveActivatedProfile(this, code = code, name = autoName, playlistUrl = playlistUrl, expiresAt = parseExpiry(expiresAt), maxDevices = 1)
        showLoadingThenGoToMain()
        return
        // --- Original dialog code below (unreachable) ---
        val input = EditText(this).apply {
            setText(serverName.ifBlank { "User $code" })
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#B8AFC8"))
            background = ColorDrawable(Color.parseColor("#3B2752"))
            setPadding(24, 24, 24, 24)
            hint = getString(R.string.enter_name)
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.code_valid_enter_name))
            .setView(input)
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                val name = input.text.toString().trim().ifBlank { serverName.ifBlank { "User $code" } }
                val parsedExpiry = parseExpiry(expiresAt)
                SourcePrefs.saveActivatedProfile(
                    this, code = code, name = name,
                    playlistUrl = playlistUrl, expiresAt = parsedExpiry, maxDevices = 1
                )
                refreshScreen()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun parseExpiry(expiryStr: String): String {
        val trimmed = expiryStr.trim()
        return when {
            trimmed.equals("24h", ignoreCase = true) ||
            trimmed.equals("24H", ignoreCase = true) ||
            trimmed.equals("1d", ignoreCase = true) ||
            trimmed.equals("1D", ignoreCase = true) ||
            trimmed.equals("يوم", ignoreCase = true) ||
            trimmed.equals("day", ignoreCase = true) -> {
                val cal = Calendar.getInstance()
                cal.add(Calendar.HOUR_OF_DAY, 24)
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
            }
            trimmed.equals("7d", ignoreCase = true) ||
            trimmed.equals("week", ignoreCase = true) ||
            trimmed.equals("أسبوع", ignoreCase = true) -> {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_MONTH, 7)
                SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
            }
            else -> trimmed
        }
    }

    @Deprecated("Deprecated in Java")
// Improved back handling - go back instead of exiting app
@Override
public void onBackPressed() {
    if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.END)) {
        drawerLayout.closeDrawer(GravityCompat.END);
    } else {
        // Go to previous screen instead of killing the app
        super.onBackPressed();
    }
    @Deprecated("Deprecated in Java")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawerLayout != null && drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END)
        } else {
            // Go back to previous screen, do NOT exit the whole app
            super.onBackPressed()
        }
    }
        super.onNewIntent(intent)
        setIntent(intent)
        refreshScreen()
    }
