package com.latchi.iptv.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.latchi.iptv.R
import com.latchi.iptv.utils.IptvProfile

class UserProfilesAdapter(
    private var profiles: List<IptvProfile>,
    private val onOpen: (IptvProfile) -> Unit,
    private val onDelete: (IptvProfile) -> Unit
) : RecyclerView.Adapter<UserProfilesAdapter.ProfileViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_user_profile, parent, false)
        return ProfileViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) = holder.bind(profiles[position])
    override fun getItemCount(): Int = profiles.size

    fun update(newProfiles: List<IptvProfile>) {
        profiles = newProfiles
        notifyDataSetChanged()
    }

    inner class ProfileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleText: TextView = itemView.findViewById(R.id.profileTitle)
        private val codeText: TextView = itemView.findViewById(R.id.profileCode)
        private val expiresText: TextView = itemView.findViewById(R.id.profileExpires)
        private val deleteButton: ImageView = itemView.findViewById(R.id.deleteButton)

        fun bind(profile: IptvProfile) {
            titleText.text = profile.name
            codeText.text = "Code: ${profile.activationCode}"
            expiresText.text = if (profile.expiresAt.isBlank()) "Expiry: not set" else "Expiry: ${profile.expiresAt}"
            itemView.setOnClickListener { onOpen(profile) }
            deleteButton.setOnClickListener { onDelete(profile) }
        }
    }
}
